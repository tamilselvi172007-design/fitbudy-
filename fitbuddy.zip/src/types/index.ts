export type FitnessGoal = 'strength' | 'hypertrophy' | 'fat_loss' | 'endurance' | 'mobility';
export type ExperienceLevel = 'beginner' | 'intermediate' | 'advanced';
export type UnitSystem = 'metric' | 'imperial';

export interface ExerciseItem {
  id: string;
  name: string;
  targetMuscle: string;
  secondaryMuscles?: string[];
  equipment: string;
  category: 'chest' | 'back' | 'legs' | 'shoulders' | 'arms' | 'core' | 'cardio';
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  instructions: string[];
  formCue: string;
  recommendedSets: number;
  recommendedReps: string;
  restSec: number;
}

export interface WorkoutExercise {
  id: string;
  name: string;
  targetMuscle: string;
  sets: number;
  reps: string;
  restSec: number;
  tips: string;
  formCue: string;
}

export interface WorkoutWarmupCooldown {
  name: string;
  durationSec: number;
  instructions: string;
}

export interface WorkoutPlan {
  id: string;
  title: string;
  description: string;
  focus: string;
  estimatedCalories: number;
  durationMinutes: number;
  warmup: WorkoutWarmupCooldown[];
  exercises: WorkoutExercise[];
  cooldown: WorkoutWarmupCooldown[];
  createdAt?: string;
  isCustom?: boolean;
}

export interface WorkoutLogEntry {
  id: string;
  workoutTitle: string;
  date: string;
  durationMinutes: number;
  caloriesBurned: number;
  totalSetsCompleted: number;
  completedExercises: {
    exerciseName: string;
    sets: { weight: number; reps: number; completed: boolean }[];
  }[];
}

export interface MealItem {
  id: string;
  name: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  fitnessScore?: string;
  timestamp: string;
}

export interface UserProfile {
  name: string;
  goal: FitnessGoal;
  level: ExperienceLevel;
  unit: UnitSystem;
  weight: number; // in kg or lbs
  targetWeight: number;
  dailyCalorieTarget: number;
  dailyWaterTargetMl: number;
  currentStreak: number;
  bestStreak: number;
  lastActiveDate: string;
}

export interface AchievementBadge {
  id: string;
  title: string;
  description: string;
  icon: string;
  unlocked: boolean;
  unlockedAt?: string;
  category: 'streak' | 'workout' | 'nutrition' | 'milestone';
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
}
