import { UserProfile, WorkoutLogEntry, MealItem, AchievementBadge, ChatMessage } from '../types';

const STORAGE_KEYS = {
  PROFILE: 'fitbuddy_user_profile',
  WORKOUT_LOGS: 'fitbuddy_workout_logs',
  MEALS: 'fitbuddy_meals',
  WATER_ML: 'fitbuddy_water_ml',
  WATER_DATE: 'fitbuddy_water_date',
  BADGES: 'fitbuddy_badges',
  CHAT: 'fitbuddy_chat_history',
};

const DEFAULT_PROFILE: UserProfile = {
  name: 'Alex Runner',
  goal: 'hypertrophy',
  level: 'intermediate',
  unit: 'metric',
  weight: 74,
  targetWeight: 72,
  dailyCalorieTarget: 2300,
  dailyWaterTargetMl: 2500,
  currentStreak: 4,
  bestStreak: 7,
  lastActiveDate: new Date().toISOString().split('T')[0],
};

export const INITIAL_BADGES: AchievementBadge[] = [
  {
    id: 'first-rep',
    title: 'First Rep',
    description: 'Complete your first workout session with FitBuddy',
    icon: 'dumbbell',
    unlocked: true,
    unlockedAt: '2026-09-28',
    category: 'milestone',
  },
  {
    id: 'streak-3',
    title: '3-Day Fire',
    description: 'Maintain a 3-day consecutive workout or activity streak',
    icon: 'flame',
    unlocked: true,
    unlockedAt: '2026-09-30',
    category: 'streak',
  },
  {
    id: 'hydration-hero',
    title: 'Hydration Hero',
    description: 'Hit your daily water target of 2,500ml',
    icon: 'droplets',
    unlocked: false,
    category: 'nutrition',
  },
  {
    id: 'iron-will',
    title: 'Iron Will',
    description: 'Log 5 workouts in a single calendar week',
    icon: 'trophy',
    unlocked: false,
    category: 'workout',
  },
  {
    id: 'century-sets',
    title: 'Century Club',
    description: 'Complete 100 total exercise sets',
    icon: 'award',
    unlocked: false,
    category: 'milestone',
  },
  {
    id: 'macro-master',
    title: 'Macro Master',
    description: 'Log at least 3 meals in a single day using AI analyzer',
    icon: 'utensils',
    unlocked: false,
    category: 'nutrition',
  },
];

export const getStoredProfile = (): UserProfile => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.PROFILE);
    if (!raw) return DEFAULT_PROFILE;
    return { ...DEFAULT_PROFILE, ...JSON.parse(raw) };
  } catch {
    return DEFAULT_PROFILE;
  }
};

export const saveStoredProfile = (profile: UserProfile): void => {
  try {
    localStorage.setItem(STORAGE_KEYS.PROFILE, JSON.stringify(profile));
  } catch {
    // ignore
  }
};

export const getStoredWorkoutLogs = (): WorkoutLogEntry[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.WORKOUT_LOGS);
    if (!raw) {
      // Seed initial realistic workout logs for rich graphs and stats
      const initialLogs: WorkoutLogEntry[] = [
        {
          id: 'log-1',
          workoutTitle: 'Push Day Hypertrophy',
          date: '2026-09-29',
          durationMinutes: 44,
          caloriesBurned: 330,
          totalSetsCompleted: 14,
          completedExercises: [
            {
              exerciseName: 'Barbell Flat Bench Press',
              sets: [
                { weight: 70, reps: 10, completed: true },
                { weight: 75, reps: 8, completed: true },
                { weight: 75, reps: 8, completed: true },
              ],
            },
            {
              exerciseName: 'Dumbbell Lateral Raise',
              sets: [
                { weight: 12, reps: 15, completed: true },
                { weight: 12, reps: 14, completed: true },
              ],
            },
          ],
        },
        {
          id: 'log-2',
          workoutTitle: 'Leg & Posterior Chain Blast',
          date: '2026-09-30',
          durationMinutes: 48,
          caloriesBurned: 410,
          totalSetsCompleted: 16,
          completedExercises: [
            {
              exerciseName: 'Barbell Back Squat',
              sets: [
                { weight: 90, reps: 8, completed: true },
                { weight: 95, reps: 8, completed: true },
                { weight: 100, reps: 6, completed: true },
              ],
            },
          ],
        },
      ];
      localStorage.setItem(STORAGE_KEYS.WORKOUT_LOGS, JSON.stringify(initialLogs));
      return initialLogs;
    }
    return JSON.parse(raw);
  } catch {
    return [];
  }
};

export const saveWorkoutLog = (entry: WorkoutLogEntry): WorkoutLogEntry[] => {
  const current = getStoredWorkoutLogs();
  const updated = [entry, ...current];
  try {
    localStorage.setItem(STORAGE_KEYS.WORKOUT_LOGS, JSON.stringify(updated));
  } catch {
    // ignore
  }

  // Update profile streak & badges
  const profile = getStoredProfile();
  const today = new Date().toISOString().split('T')[0];
  if (profile.lastActiveDate !== today) {
    const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];
    if (profile.lastActiveDate === yesterday) {
      profile.currentStreak += 1;
    } else {
      profile.currentStreak = 1;
    }
    if (profile.currentStreak > profile.bestStreak) {
      profile.bestStreak = profile.currentStreak;
    }
    profile.lastActiveDate = today;
    saveStoredProfile(profile);
  }

  return updated;
};

export const getStoredWater = (): number => {
  try {
    const savedDate = localStorage.getItem(STORAGE_KEYS.WATER_DATE);
    const today = new Date().toISOString().split('T')[0];
    if (savedDate !== today) {
      localStorage.setItem(STORAGE_KEYS.WATER_DATE, today);
      localStorage.setItem(STORAGE_KEYS.WATER_ML, '750'); // start with morning glass
      return 750;
    }
    const val = localStorage.getItem(STORAGE_KEYS.WATER_ML);
    return val ? Number(val) : 750;
  } catch {
    return 750;
  }
};

export const saveStoredWater = (amountMl: number): void => {
  try {
    const today = new Date().toISOString().split('T')[0];
    localStorage.setItem(STORAGE_KEYS.WATER_DATE, today);
    localStorage.setItem(STORAGE_KEYS.WATER_ML, String(amountMl));
  } catch {
    // ignore
  }
};

export const getStoredMeals = (): MealItem[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.MEALS);
    if (!raw) {
      const initialMeals: MealItem[] = [
        {
          id: 'meal-1',
          name: 'Post-Workout Oatmeal & Whey Protein',
          calories: 420,
          protein: 36,
          carbs: 52,
          fat: 8,
          fitnessScore: 'A+',
          timestamp: '08:30 AM',
        },
        {
          id: 'meal-2',
          name: 'Grilled Chicken, Brown Rice & Asparagus',
          calories: 580,
          protein: 48,
          carbs: 64,
          fat: 12,
          fitnessScore: 'A',
          timestamp: '01:15 PM',
        },
      ];
      localStorage.setItem(STORAGE_KEYS.MEALS, JSON.stringify(initialMeals));
      return initialMeals;
    }
    return JSON.parse(raw);
  } catch {
    return [];
  }
};

export const saveStoredMeals = (meals: MealItem[]): void => {
  try {
    localStorage.setItem(STORAGE_KEYS.MEALS, JSON.stringify(meals));
  } catch {
    // ignore
  }
};

export const getStoredBadges = (): AchievementBadge[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.BADGES);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.BADGES, JSON.stringify(INITIAL_BADGES));
      return INITIAL_BADGES;
    }
    return JSON.parse(raw);
  } catch {
    return INITIAL_BADGES;
  }
};

export const unlockBadge = (badgeId: string): AchievementBadge[] => {
  const badges = getStoredBadges();
  const updated = badges.map((b) => {
    if (b.id === badgeId && !b.unlocked) {
      return { ...b, unlocked: true, unlockedAt: new Date().toISOString().split('T')[0] };
    }
    return b;
  });
  try {
    localStorage.setItem(STORAGE_KEYS.BADGES, JSON.stringify(updated));
  } catch {
    // ignore
  }
  return updated;
};

export const getStoredChat = (): ChatMessage[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.CHAT);
    if (!raw) {
      const welcome: ChatMessage[] = [
        {
          id: 'msg-0',
          role: 'assistant',
          content: "Hey athlete! I'm FitBuddy, your personal fitness coach. Whether you need workout modifications, form cues, recovery guidance, or macro targets, ask away. What are we targeting today?",
          timestamp: 'Just now',
        },
      ];
      localStorage.setItem(STORAGE_KEYS.CHAT, JSON.stringify(welcome));
      return welcome;
    }
    return JSON.parse(raw);
  } catch {
    return [];
  }
};

export const saveStoredChat = (chat: ChatMessage[]): void => {
  try {
    localStorage.setItem(STORAGE_KEYS.CHAT, JSON.stringify(chat));
  } catch {
    // ignore
  }
};
