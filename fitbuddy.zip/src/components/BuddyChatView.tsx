import React, { useState, useRef, useEffect } from 'react';
import {
  Send,
  Sparkles,
  Bot,
  User,
  RotateCw,
  RefreshCw,
  Dumbbell,
  Zap,
} from 'lucide-react';
import { ChatMessage, UserProfile } from '../types';

interface BuddyChatViewProps {
  profile: UserProfile;
  messages: ChatMessage[];
  onSendMessage: (userText: string) => Promise<void>;
  onClearChat: () => void;
  isThinking: boolean;
}

export const BuddyChatView: React.FC<BuddyChatViewProps> = ({
  profile,
  messages,
  onSendMessage,
  onClearChat,
  isThinking,
}) => {
  const [inputText, setInputText] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isThinking]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || isThinking) return;
    const text = inputText;
    setInputText('');
    await onSendMessage(text);
  };

  const promptSuggestions = [
    'How much protein do I need for my current weight?',
    'How do I fix elbow flare on barbell bench press?',
    'Give me a 10-minute core burner I can do right now.',
    'Best active recovery protocol for sore hamstrings?',
    'What should I eat 1 hour before a heavy leg workout?',
  ];

  return (
    <div className="flex flex-col h-[calc(100vh-140px)] min-h-[500px] max-h-[820px] rounded-2xl border border-zinc-800 bg-zinc-900/90 shadow-2xl overflow-hidden">
      {/* Top Bar */}
      <div className="flex items-center justify-between border-b border-zinc-800 bg-zinc-950 px-4 py-3 sm:px-6">
        <div className="flex items-center gap-3">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-lime-400 text-zinc-950 shadow-sm shadow-lime-400/20">
            <Sparkles className="h-5 w-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="font-display text-base font-bold text-zinc-100">FitBuddy AI Coach</h2>
              <span className="flex h-2 w-2 rounded-full bg-lime-400 animate-pulse" />
            </div>
            <p className="text-xs text-zinc-400">
              Personalized for {profile.name} · {profile.goal}
            </p>
          </div>
        </div>

        <button
          onClick={onClearChat}
          className="flex items-center gap-1 text-xs text-zinc-400 hover:text-zinc-200 transition-colors p-1"
          title="Reset conversation"
        >
          <RefreshCw className="h-3.5 w-3.5" />
          <span className="hidden sm:inline">Reset</span>
        </button>
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
        {messages.map((msg) => {
          const isUser = msg.role === 'user';
          return (
            <div
              key={msg.id}
              className={`flex items-start gap-3 ${isUser ? 'flex-row-reverse' : 'flex-row'}`}
            >
              <div
                className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-xs font-bold ${
                  isUser
                    ? 'bg-zinc-800 text-zinc-200 border border-zinc-700'
                    : 'bg-lime-400 text-zinc-950'
                }`}
              >
                {isUser ? <User className="h-4 w-4" /> : <Bot className="h-4 w-4" />}
              </div>

              <div
                className={`max-w-[85%] sm:max-w-[75%] rounded-2xl px-4 py-3 text-xs sm:text-sm leading-relaxed ${
                  isUser
                    ? 'bg-zinc-800 text-zinc-100 border border-zinc-700/80 rounded-tr-sm'
                    : 'bg-zinc-950 text-zinc-200 border border-zinc-800 rounded-tl-sm'
                }`}
              >
                <div className="whitespace-pre-wrap">{msg.content}</div>
                <div
                  className={`mt-1.5 text-[10px] tabular-nums ${
                    isUser ? 'text-zinc-400 text-right' : 'text-zinc-500'
                  }`}
                >
                  {msg.timestamp}
                </div>
              </div>
            </div>
          );
        })}

        {isThinking && (
          <div className="flex items-center gap-3">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-lime-400 text-zinc-950">
              <Bot className="h-4 w-4" />
            </div>
            <div className="rounded-2xl bg-zinc-950 border border-zinc-800 px-4 py-3 rounded-tl-sm">
              <div className="flex items-center gap-2 text-xs text-zinc-400">
                <RotateCw className="h-3.5 w-3.5 animate-spin text-lime-400" />
                <span>FitBuddy is formulating coaching advice...</span>
              </div>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Suggested Prompt Chips */}
      <div className="border-t border-zinc-800/80 bg-zinc-950/60 px-4 py-2 overflow-x-auto scrollbar-none flex items-center gap-2">
        <span className="text-[11px] font-semibold text-zinc-400 shrink-0">Prompts:</span>
        {promptSuggestions.map((prompt, idx) => (
          <button
            key={idx}
            onClick={() => onSendMessage(prompt)}
            className="rounded-lg border border-zinc-800 bg-zinc-900 px-2.5 py-1 text-xs text-zinc-300 hover:border-lime-400/50 hover:text-white whitespace-nowrap transition-colors shrink-0"
          >
            {prompt}
          </button>
        ))}
      </div>

      {/* Chat Input Bar */}
      <form
        onSubmit={handleSubmit}
        className="flex items-center gap-2 border-t border-zinc-800 bg-zinc-950 p-3 sm:p-4"
      >
        <input
          type="text"
          placeholder="Ask FitBuddy anything about workouts, biomechanics, recovery, or diet..."
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          className="flex-1 rounded-xl border border-zinc-800 bg-zinc-900 px-4 py-3 text-xs sm:text-sm text-zinc-100 placeholder:text-zinc-500 focus:border-lime-400 focus:outline-none"
        />
        <button
          type="submit"
          disabled={!inputText.trim() || isThinking}
          className="flex h-11 w-11 items-center justify-center rounded-xl bg-lime-400 text-zinc-950 shadow-md shadow-lime-400/20 transition-all hover:bg-lime-300 active:scale-95 disabled:opacity-40 shrink-0"
        >
          <Send className="h-4 w-4" />
        </button>
      </form>
    </div>
  );
};
