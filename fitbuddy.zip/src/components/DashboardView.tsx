import React, { useState } from 'react';
import {
  Flame,
  Dumbbell,
  Droplets,
  Utensils,
  Plus,
  Play,
  ArrowRight,
  TrendingUp,
  Clock,
  Sparkles,
  CheckCircle2,
} from 'lucide-react';
import { UserProfile, WorkoutPlan, WorkoutLogEntry, MealItem } from '../types';
import heroAthleteImg from '../assets/images/fitbuddy_hero_athlete_1790845457738.jpg';
import workoutStrengthImg from '../assets/images/fitbuddy_workout_strength_1790845471772.jpg';
import workoutHiitImg from '../assets/images/fitbuddy_workout_hiit_1790845484326.jpg';
import nutritionBowlImg from '../assets/images/fitbuddy_nutrition_healthy_1790845497084.jpg';

interface DashboardViewProps {
  profile: UserProfile;
  waterMl: number;
  onAddWater: (amount: number) => void;
  todayMeals: MealItem[];
  recentLogs: WorkoutLogEntry[];
  recommendedWorkout: WorkoutPlan;
  onStartWorkout: (workout: WorkoutPlan) => void;
  onNavigate: (tab: 'workouts' | 'exercises' | 'nutrition' | 'coach' | 'profile') => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  profile,
  waterMl,
  onAddWater,
  todayMeals,
  recentLogs,
  recommendedWorkout,
  onStartWorkout,
  onNavigate,
}) => {
  const [imgErrorHero, setImgErrorHero] = useState(false);
  const [imgErrorStrength, setImgErrorStrength] = useState(false);
  const [imgErrorHiit, setImgErrorHiit] = useState(false);
  const [imgErrorNutrition, setImgErrorNutrition] = useState(false);

  // Nutrition summaries
  const totalCaloriesLogged = todayMeals.reduce((acc, m) => acc + m.calories, 0);
  const totalProteinLogged = todayMeals.reduce((acc, m) => acc + m.protein, 0);

  // 7-day streak representation
  const days = ['M', 'T', 'W', 'T', 'F', 'S', 'S'];
  const todayDayIdx = (new Date().getDay() + 6) % 7; // Monday = 0

  return (
    <div className="space-y-8 pb-12">
      {/* Welcome & Streak Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <span className="text-xs font-semibold text-lime-400 uppercase tracking-wider">
            Ready to train
          </span>
          <h1 className="font-display text-2xl sm:text-3xl font-extrabold text-zinc-100">
            Welcome back, {profile.name}
          </h1>
          <p className="mt-1 text-sm text-zinc-400">
            Current Focus: <span className="text-zinc-200 capitalize">{profile.goal}</span> · Day {profile.currentStreak} of your streak
          </p>
        </div>

        {/* 7-Day Micro Tracker */}
        <div className="flex items-center gap-1.5 rounded-xl border border-zinc-800 bg-zinc-900/90 p-2.5">
          {days.map((day, idx) => {
            const isToday = idx === todayDayIdx;
            const isCompleted = idx <= todayDayIdx;
            return (
              <div key={idx} className="flex flex-col items-center gap-1">
                <span className="text-[10px] font-semibold text-zinc-400">{day}</span>
                <div
                  className={`flex h-7 w-7 items-center justify-center rounded-lg text-xs font-bold transition-colors tabular-nums ${
                    isToday
                      ? 'bg-lime-400 text-zinc-950 shadow-sm shadow-lime-400/30'
                      : isCompleted
                      ? 'bg-zinc-800 text-lime-400 border border-lime-400/20'
                      : 'bg-zinc-950 text-zinc-400'
                  }`}
                >
                  {isCompleted ? <CheckCircle2 className="h-3.5 w-3.5" /> : idx + 1}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Core Metrics 4-Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        {/* Streak Metric */}
        <div className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-4 transition-colors hover:border-zinc-700">
          <div className="flex items-center justify-between text-zinc-400">
            <span className="text-xs font-medium">Daily Streak</span>
            <Flame className="h-4 w-4 text-amber-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-1">
            <span className="font-display text-2xl sm:text-3xl font-bold text-zinc-100 tabular-nums">
              {profile.currentStreak}
            </span>
            <span className="text-xs text-zinc-400">days</span>
          </div>
          <p className="mt-1 text-xs text-zinc-400">Personal Best: {profile.bestStreak} days</p>
        </div>

        {/* Calories Metric */}
        <div className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-4 transition-colors hover:border-zinc-700">
          <div className="flex items-center justify-between text-zinc-400">
            <span className="text-xs font-medium">Calories Logged</span>
            <Utensils className="h-4 w-4 text-lime-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-1">
            <span className="font-display text-2xl sm:text-3xl font-bold text-zinc-100 tabular-nums">
              {totalCaloriesLogged}
            </span>
            <span className="text-xs text-zinc-400">/ {profile.dailyCalorieTarget}</span>
          </div>
          <div className="mt-2 h-1.5 w-full rounded-full bg-zinc-800 overflow-hidden">
            <div
              className="h-full bg-lime-400"
              style={{
                width: `${Math.min(100, (totalCaloriesLogged / profile.dailyCalorieTarget) * 100)}%`,
              }}
            />
          </div>
        </div>

        {/* Water Intake with Quick Add */}
        <div className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-4 transition-colors hover:border-zinc-700">
          <div className="flex items-center justify-between text-zinc-400">
            <span className="text-xs font-medium">Hydration</span>
            <Droplets className="h-4 w-4 text-cyan-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-1">
            <span className="font-display text-2xl sm:text-3xl font-bold text-zinc-100 tabular-nums">
              {waterMl}
            </span>
            <span className="text-xs text-zinc-400">/ {profile.dailyWaterTargetMl} ml</span>
          </div>
          <div className="mt-2 flex items-center justify-between gap-1">
            <div className="h-1.5 w-2/3 rounded-full bg-zinc-800 overflow-hidden">
              <div
                className="h-full bg-cyan-400 transition-all duration-300"
                style={{
                  width: `${Math.min(100, (waterMl / profile.dailyWaterTargetMl) * 100)}%`,
                }}
              />
            </div>
            <button
              onClick={() => onAddWater(250)}
              className="flex items-center gap-1 rounded bg-zinc-800 px-2 py-0.5 text-[11px] font-semibold text-cyan-300 hover:bg-zinc-700 active:scale-95"
            >
              <Plus className="h-3 w-3" /> 250ml
            </button>
          </div>
        </div>

        {/* Active Workouts Metric */}
        <div className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-4 transition-colors hover:border-zinc-700">
          <div className="flex items-center justify-between text-zinc-400">
            <span className="text-xs font-medium">Workouts This Week</span>
            <Dumbbell className="h-4 w-4 text-purple-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-1">
            <span className="font-display text-2xl sm:text-3xl font-bold text-zinc-100 tabular-nums">
              {recentLogs.length}
            </span>
            <span className="text-xs text-zinc-400">sessions</span>
          </div>
          <p className="mt-1 text-xs text-zinc-400">
            {recentLogs.reduce((acc, l) => acc + l.durationMinutes, 0)} total active minutes
          </p>
        </div>
      </div>

      {/* Featured Workout of the Day Hero Banner */}
      <div className="relative overflow-hidden rounded-2xl border border-zinc-800 bg-zinc-900 shadow-xl">
        <div className="grid grid-cols-1 lg:grid-cols-12 items-stretch min-h-[340px]">
          <div className="p-6 sm:p-8 lg:col-span-7 flex flex-col justify-between z-10">
            <div>
              <div className="flex items-center gap-2 text-xs font-semibold text-lime-400">
                <Sparkles className="h-4 w-4" />
                <span>Featured Training Session</span>
              </div>
              <h2 className="mt-2 font-display text-2xl sm:text-3xl font-extrabold text-zinc-100">
                {recommendedWorkout.title}
              </h2>
              <p className="mt-2 text-sm text-zinc-300 line-clamp-2 max-w-xl">
                {recommendedWorkout.description}
              </p>

              {/* Workout Details Row */}
              <div className="mt-4 flex flex-wrap items-center gap-3 text-xs text-zinc-400">
                <span className="flex items-center gap-1 font-medium text-zinc-200">
                  <Clock className="h-3.5 w-3.5 text-zinc-400" />
                  {recommendedWorkout.durationMinutes} mins
                </span>
                <span aria-hidden="true">·</span>
                <span>{recommendedWorkout.exercises.length} Exercises</span>
                <span aria-hidden="true">·</span>
                <span className="tabular-nums font-mono text-zinc-200">
                  ~{recommendedWorkout.estimatedCalories} kcal
                </span>
                <span aria-hidden="true">·</span>
                <span className="text-lime-400">{recommendedWorkout.focus}</span>
              </div>
            </div>

            <div className="mt-6 flex flex-wrap items-center gap-3">
              <button
                onClick={() => onStartWorkout(recommendedWorkout)}
                className="flex items-center gap-2 rounded-xl bg-lime-400 px-6 py-3 text-sm font-bold text-zinc-950 shadow-lg shadow-lime-400/20 transition-all hover:bg-lime-300 active:scale-[0.98]"
              >
                <Play className="h-4 w-4 fill-current" />
                Start Live Workout
              </button>
              <button
                onClick={() => onNavigate('workouts')}
                className="flex items-center gap-1.5 rounded-xl border border-zinc-700 bg-zinc-800/80 px-4 py-3 text-sm font-semibold text-zinc-200 transition-colors hover:bg-zinc-700 hover:text-white"
              >
                View Full Routine
                <ArrowRight className="h-4 w-4" />
              </button>
            </div>
          </div>

          {/* Hero Visual Column */}
          <div className="relative lg:col-span-5 min-h-[220px] lg:min-h-full overflow-hidden bg-zinc-950">
            {!imgErrorHero ? (
              <img
                src={heroAthleteImg}
                alt="FitBuddy athlete ready for training"
                referrerPolicy="no-referrer"
                onError={() => setImgErrorHero(true)}
                className="h-full w-full object-cover object-center opacity-90 transition-transform duration-700 hover:scale-105"
              />
            ) : (
              <div className="flex h-full w-full items-center justify-center bg-zinc-950">
                <Dumbbell className="h-16 w-16 text-zinc-700" />
              </div>
            )}
            <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-transparent to-transparent lg:bg-gradient-to-r lg:from-zinc-900 lg:via-transparent lg:to-transparent" />
          </div>
        </div>
      </div>

      {/* Bento Grid: 3 Pillars (Strength, Conditioning & AI Nutrition) */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-display text-xl font-bold text-zinc-100">Training & Nutrition Hub</h2>
          <button
            onClick={() => onNavigate('workouts')}
            className="text-xs font-semibold text-lime-400 hover:text-lime-300 flex items-center gap-1"
          >
            All Workouts <ArrowRight className="h-3.5 w-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Card 1: Strength */}
          <div
            onClick={() => onNavigate('workouts')}
            className="group cursor-pointer overflow-hidden rounded-2xl border border-zinc-800 bg-zinc-900 transition-all hover:border-zinc-700 hover:shadow-xl"
          >
            <div className="relative h-44 overflow-hidden bg-zinc-950">
              {!imgErrorStrength ? (
                <img
                  src={workoutStrengthImg}
                  alt="Strength training session"
                  referrerPolicy="no-referrer"
                  onError={() => setImgErrorStrength(true)}
                  className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
              ) : (
                <div className="flex h-full w-full items-center justify-center bg-zinc-950 text-zinc-700">
                  <Dumbbell className="h-12 w-12" />
                </div>
              )}
              <div className="absolute inset-0 bg-gradient-to-t from-zinc-900 via-transparent to-transparent" />
            </div>
            <div className="p-4">
              <span className="text-xs font-semibold text-lime-400">Hypertrophy & Power</span>
              <h3 className="font-display text-lg font-bold text-zinc-100 group-hover:text-lime-400 transition-colors">
                Compound Strength Splits
              </h3>
              <p className="mt-1 text-xs text-zinc-400 line-clamp-2">
                Progressive overload routines designed to stimulate muscle hypertrophy and joint resilience.
              </p>
            </div>
          </div>

          {/* Card 2: HIIT */}
          <div
            onClick={() => onNavigate('workouts')}
            className="group cursor-pointer overflow-hidden rounded-2xl border border-zinc-800 bg-zinc-900 transition-all hover:border-zinc-700 hover:shadow-xl"
          >
            <div className="relative h-44 overflow-hidden bg-zinc-950">
              {!imgErrorHiit ? (
                <img
                  src={workoutHiitImg}
                  alt="High intensity interval conditioning"
                  referrerPolicy="no-referrer"
                  onError={() => setImgErrorHiit(true)}
                  className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
              ) : (
                <div className="flex h-full w-full items-center justify-center bg-zinc-950 text-zinc-700">
                  <TrendingUp className="h-12 w-12" />
                </div>
              )}
              <div className="absolute inset-0 bg-gradient-to-t from-zinc-900 via-transparent to-transparent" />
            </div>
            <div className="p-4">
              <span className="text-xs font-semibold text-amber-400">Metabolic Conditioning</span>
              <h3 className="font-display text-lg font-bold text-zinc-100 group-hover:text-amber-400 transition-colors">
                HIIT & Athletic Cardio
              </h3>
              <p className="mt-1 text-xs text-zinc-400 line-clamp-2">
                Interval sprints, plyometrics, and calisthenics to elevate VO2 max and caloric expenditure.
              </p>
            </div>
          </div>

          {/* Card 3: Nutrition */}
          <div
            onClick={() => onNavigate('nutrition')}
            className="group cursor-pointer overflow-hidden rounded-2xl border border-zinc-800 bg-zinc-900 transition-all hover:border-zinc-700 hover:shadow-xl"
          >
            <div className="relative h-44 overflow-hidden bg-zinc-950">
              {!imgErrorNutrition ? (
                <img
                  src={nutritionBowlImg}
                  alt="High protein healthy nutrition"
                  referrerPolicy="no-referrer"
                  onError={() => setImgErrorNutrition(true)}
                  className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
              ) : (
                <div className="flex h-full w-full items-center justify-center bg-zinc-950 text-zinc-700">
                  <Utensils className="h-12 w-12" />
                </div>
              )}
              <div className="absolute inset-0 bg-gradient-to-t from-zinc-900 via-transparent to-transparent" />
            </div>
            <div className="p-4">
              <span className="text-xs font-semibold text-cyan-400">AI Macro Coach</span>
              <h3 className="font-display text-lg font-bold text-zinc-100 group-hover:text-cyan-400 transition-colors">
                Smart Fuel & Nutrition
              </h3>
              <p className="mt-1 text-xs text-zinc-400 line-clamp-2">
                Type meals in plain English to instantly estimate protein, carbs, healthy fats, and health ratings.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Launch Coach Banner */}
      <div className="rounded-2xl border border-lime-400/20 bg-gradient-to-r from-lime-950/40 via-zinc-900 to-zinc-900 p-6 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-lime-400 text-zinc-950 font-bold shadow-md shadow-lime-400/20">
            <Sparkles className="h-6 w-6" />
          </div>
          <div>
            <h3 className="font-display text-lg font-bold text-zinc-100">Need Form Advice or a Routine Tweak?</h3>
            <p className="text-xs sm:text-sm text-zinc-400">
              FitBuddy AI is ready 24/7 to provide coaching cues, substitution exercises, or recovery strategies.
            </p>
          </div>
        </div>
        <button
          onClick={() => onNavigate('coach')}
          className="rounded-xl bg-lime-400 px-5 py-2.5 text-xs sm:text-sm font-bold text-zinc-950 hover:bg-lime-300 active:scale-[0.98] whitespace-nowrap"
        >
          Talk with Coach
        </button>
      </div>
    </div>
  );
};
