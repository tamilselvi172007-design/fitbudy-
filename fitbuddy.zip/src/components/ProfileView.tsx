import React, { useState } from 'react';
import {
  User,
  Award,
  Flame,
  Dumbbell,
  CheckCircle2,
  Lock,
  Clock,
  Calendar,
  Save,
  Check,
} from 'lucide-react';
import { UserProfile, WorkoutLogEntry, AchievementBadge, FitnessGoal, ExperienceLevel, UnitSystem } from '../types';

interface ProfileViewProps {
  profile: UserProfile;
  onUpdateProfile: (updated: UserProfile) => void;
  badges: AchievementBadge[];
  workoutLogs: WorkoutLogEntry[];
}

export const ProfileView: React.FC<ProfileViewProps> = ({
  profile,
  onUpdateProfile,
  badges,
  workoutLogs,
}) => {
  const [name, setName] = useState(profile.name);
  const [goal, setGoal] = useState<FitnessGoal>(profile.goal);
  const [level, setLevel] = useState<ExperienceLevel>(profile.level);
  const [unit, setUnit] = useState<UnitSystem>(profile.unit);
  const [weight, setWeight] = useState(profile.weight);
  const [targetWeight, setTargetWeight] = useState(profile.targetWeight);
  const [dailyCalories, setDailyCalories] = useState(profile.dailyCalorieTarget);
  const [dailyWater, setDailyWater] = useState(profile.dailyWaterTargetMl);
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const updated: UserProfile = {
      ...profile,
      name,
      goal,
      level,
      unit,
      weight: Number(weight),
      targetWeight: Number(targetWeight),
      dailyCalorieTarget: Number(dailyCalories),
      dailyWaterTargetMl: Number(dailyWater),
    };
    onUpdateProfile(updated);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  const totalMinutesTrained = workoutLogs.reduce((acc, log) => acc + log.durationMinutes, 0);
  const totalCaloriesBurned = workoutLogs.reduce((acc, log) => acc + log.caloriesBurned, 0);
  const totalSetsLogged = workoutLogs.reduce((acc, log) => acc + log.totalSetsCompleted, 0);

  return (
    <div className="space-y-8 pb-12">
      {/* Header */}
      <div>
        <span className="text-xs font-semibold text-lime-400 uppercase tracking-wider">
          Athlete Credentials
        </span>
        <h1 className="font-display text-2xl sm:text-3xl font-extrabold text-zinc-100">
          Profile & Training History
        </h1>
        <p className="mt-1 text-sm text-zinc-400">
          Manage your biometrics, inspect earned achievement badges, and review training archives.
        </p>
      </div>

      {/* Career Stats 3-Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 sm:gap-4">
        <div className="rounded-2xl border border-zinc-800 bg-zinc-900/80 p-5">
          <div className="flex items-center justify-between text-zinc-400">
            <span className="text-xs font-medium">Total Training Time</span>
            <Clock className="h-4 w-4 text-lime-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-1">
            <span className="font-display text-2xl sm:text-3xl font-bold text-zinc-100 tabular-nums">
              {totalMinutesTrained}
            </span>
            <span className="text-xs text-zinc-400">minutes</span>
          </div>
          <p className="text-xs text-zinc-500 mt-1">Across {workoutLogs.length} logged sessions</p>
        </div>

        <div className="rounded-2xl border border-zinc-800 bg-zinc-900/80 p-5">
          <div className="flex items-center justify-between text-zinc-400">
            <span className="text-xs font-medium">Lifetime Sets Completed</span>
            <Dumbbell className="h-4 w-4 text-cyan-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-1">
            <span className="font-display text-2xl sm:text-3xl font-bold text-zinc-100 tabular-nums">
              {totalSetsLogged}
            </span>
            <span className="text-xs text-zinc-400">sets</span>
          </div>
          <p className="text-xs text-zinc-500 mt-1">Every repetition counts toward progress</p>
        </div>

        <div className="rounded-2xl border border-zinc-800 bg-zinc-900/80 p-5">
          <div className="flex items-center justify-between text-zinc-400">
            <span className="text-xs font-medium">Est. Energy Expended</span>
            <Flame className="h-4 w-4 text-amber-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-1">
            <span className="font-display text-2xl sm:text-3xl font-bold text-zinc-100 tabular-nums">
              {totalCaloriesBurned}
            </span>
            <span className="text-xs text-zinc-400">kcal</span>
          </div>
          <p className="text-xs text-zinc-500 mt-1">Workout expenditure recorded</p>
        </div>
      </div>

      {/* Athlete Settings Form */}
      <div className="rounded-2xl border border-zinc-800 bg-zinc-900/80 p-5 sm:p-6 shadow-xl">
        <div className="flex items-center justify-between border-b border-zinc-800 pb-4 mb-5">
          <div className="flex items-center gap-2">
            <User className="h-5 w-5 text-lime-400" />
            <h2 className="font-display text-lg font-bold text-zinc-100">Biometric Settings</h2>
          </div>
          {savedSuccess && (
            <span className="flex items-center gap-1 text-xs font-semibold text-lime-400 animate-in fade-in">
              <Check className="h-4 w-4" /> Preferences Saved
            </span>
          )}
        </div>

        <form onSubmit={handleSave} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-zinc-300 mb-1">Athlete Name</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full rounded-xl border border-zinc-800 bg-zinc-950 px-3.5 py-2.5 text-xs text-zinc-200 focus:border-lime-400 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-zinc-300 mb-1">Measurement Unit</label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setUnit('metric')}
                  className={`rounded-xl border py-2 text-xs font-semibold transition-all ${
                    unit === 'metric'
                      ? 'border-lime-400 bg-lime-400/10 text-lime-400'
                      : 'border-zinc-800 bg-zinc-950 text-zinc-400 hover:border-zinc-700'
                  }`}
                >
                  Metric (kg / ml)
                </button>
                <button
                  type="button"
                  onClick={() => setUnit('imperial')}
                  className={`rounded-xl border py-2 text-xs font-semibold transition-all ${
                    unit === 'imperial'
                      ? 'border-lime-400 bg-lime-400/10 text-lime-400'
                      : 'border-zinc-800 bg-zinc-950 text-zinc-400 hover:border-zinc-700'
                  }`}
                >
                  Imperial (lbs / fl oz)
                </button>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-zinc-300 mb-1">
                Current Weight ({unit === 'metric' ? 'kg' : 'lbs'})
              </label>
              <input
                type="number"
                value={weight}
                onChange={(e) => setWeight(Number(e.target.value))}
                className="w-full rounded-xl border border-zinc-800 bg-zinc-950 px-3.5 py-2.5 text-xs font-mono text-zinc-200 focus:border-lime-400 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-zinc-300 mb-1">
                Target Weight ({unit === 'metric' ? 'kg' : 'lbs'})
              </label>
              <input
                type="number"
                value={targetWeight}
                onChange={(e) => setTargetWeight(Number(e.target.value))}
                className="w-full rounded-xl border border-zinc-800 bg-zinc-950 px-3.5 py-2.5 text-xs font-mono text-zinc-200 focus:border-lime-400 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-zinc-300 mb-1">
                Daily Caloric Target (kcal)
              </label>
              <input
                type="number"
                value={dailyCalories}
                onChange={(e) => setDailyCalories(Number(e.target.value))}
                className="w-full rounded-xl border border-zinc-800 bg-zinc-950 px-3.5 py-2.5 text-xs font-mono text-zinc-200 focus:border-lime-400 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-zinc-300 mb-1">
                Daily Hydration Target (ml)
              </label>
              <input
                type="number"
                value={dailyWater}
                onChange={(e) => setDailyWater(Number(e.target.value))}
                className="w-full rounded-xl border border-zinc-800 bg-zinc-950 px-3.5 py-2.5 text-xs font-mono text-zinc-200 focus:border-lime-400 focus:outline-none"
              />
            </div>
          </div>

          <div className="pt-2 flex justify-end">
            <button
              type="submit"
              className="flex items-center gap-2 rounded-xl bg-lime-400 px-5 py-2.5 text-xs font-bold text-zinc-950 hover:bg-lime-300 active:scale-[0.98]"
            >
              <Save className="h-4 w-4" />
              Save Preferences
            </button>
          </div>
        </form>
      </div>

      {/* Achievement Badges Section */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="font-display text-xl font-bold text-zinc-100">Achievement Badges</h2>
            <p className="text-xs text-zinc-400">Unlock trophies as your consistency grows.</p>
          </div>
          <span className="text-xs font-mono font-semibold text-lime-400">
            {badges.filter((b) => b.unlocked).length} / {badges.length} Unlocked
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {badges.map((badge) => (
            <div
              key={badge.id}
              className={`rounded-2xl border p-4 transition-all ${
                badge.unlocked
                  ? 'border-lime-500/30 bg-lime-950/20 text-zinc-100 shadow-md shadow-lime-950/20'
                  : 'border-zinc-800 bg-zinc-900/40 text-zinc-500 opacity-60'
              }`}
            >
              <div className="flex items-start justify-between">
                <div
                  className={`flex h-10 w-10 items-center justify-center rounded-xl ${
                    badge.unlocked ? 'bg-lime-400 text-zinc-950' : 'bg-zinc-800 text-zinc-600'
                  }`}
                >
                  <Award className="h-5 w-5" />
                </div>
                {badge.unlocked ? (
                  <span className="flex items-center gap-1 text-[11px] font-semibold text-lime-400">
                    <CheckCircle2 className="h-3.5 w-3.5" /> Unlocked
                  </span>
                ) : (
                  <span className="flex items-center gap-1 text-[11px] text-zinc-600">
                    <Lock className="h-3.5 w-3.5" /> Locked
                  </span>
                )}
              </div>

              <h3 className="font-display text-base font-bold mt-3 text-zinc-200">
                {badge.title}
              </h3>
              <p className="text-xs text-zinc-400 mt-1">{badge.description}</p>
              {badge.unlockedAt && (
                <p className="text-[10px] text-zinc-500 font-mono mt-2">Achieved {badge.unlockedAt}</p>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Workout History Archive */}
      <div className="rounded-2xl border border-zinc-800 bg-zinc-900/70 p-5">
        <h2 className="font-display text-xl font-bold text-zinc-100 mb-4">
          Workout History Archive ({workoutLogs.length})
        </h2>

        {workoutLogs.length === 0 ? (
          <p className="text-xs text-zinc-500 py-6 text-center">
            No workouts logged yet. Complete your first session to build your training history!
          </p>
        ) : (
          <div className="space-y-3">
            {workoutLogs.map((log) => (
              <div
                key={log.id}
                className="rounded-xl border border-zinc-800 bg-zinc-950/80 p-4 transition-colors hover:border-zinc-700"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-zinc-900 pb-2.5">
                  <div>
                    <h3 className="font-display text-base font-bold text-zinc-100">
                      {log.workoutTitle}
                    </h3>
                    <div className="flex items-center gap-2 text-xs text-zinc-400 mt-0.5">
                      <span className="flex items-center gap-1">
                        <Calendar className="h-3.5 w-3.5" /> {log.date}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono tabular-nums">{log.durationMinutes} min</span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono text-amber-400 tabular-nums">
                        {log.caloriesBurned} kcal
                      </span>
                    </div>
                  </div>

                  <span className="rounded bg-zinc-900 px-2.5 py-1 text-xs font-mono font-semibold text-lime-400 tabular-nums self-start sm:self-center">
                    {log.totalSetsCompleted} sets logged
                  </span>
                </div>

                {/* Sub exercise tags */}
                <div className="mt-2.5 flex flex-wrap gap-1.5">
                  {log.completedExercises.map((ex, i) => (
                    <span
                      key={i}
                      className="rounded bg-zinc-900 border border-zinc-800 px-2 py-0.5 text-[11px] text-zinc-300"
                    >
                      {ex.exerciseName}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
