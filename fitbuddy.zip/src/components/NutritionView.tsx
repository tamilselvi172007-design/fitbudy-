import React, { useState } from 'react';
import {
  Utensils,
  Droplets,
  Plus,
  Sparkles,
  RotateCw,
  Trash2,
  CheckCircle2,
  PieChart,
  Zap,
} from 'lucide-react';
import { MealItem, UserProfile } from '../types';

interface NutritionViewProps {
  profile: UserProfile;
  meals: MealItem[];
  onAddMeal: (meal: MealItem) => void;
  onDeleteMeal: (id: string) => void;
  waterMl: number;
  onAddWater: (amount: number) => void;
}

export const NutritionView: React.FC<NutritionViewProps> = ({
  profile,
  meals,
  onAddMeal,
  onDeleteMeal,
  waterMl,
  onAddWater,
}) => {
  const [mealInput, setMealInput] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<{
    mealName: string;
    calories: number;
    protein: number;
    carbs: number;
    fat: number;
    fitnessScore: string;
    verdict: string;
    macroInsight: string;
  } | null>(null);

  // Totals
  const totalCalories = meals.reduce((sum, m) => sum + m.calories, 0);
  const totalProtein = meals.reduce((sum, m) => sum + m.protein, 0);
  const totalCarbs = meals.reduce((sum, m) => sum + m.carbs, 0);
  const totalFat = meals.reduce((sum, m) => sum + m.fat, 0);

  // Targets (derived from profile weight and calorie targets)
  const targetCalories = profile.dailyCalorieTarget || 2300;
  const targetProtein = Math.round(profile.weight * 2.0); // 2g per kg
  const targetFat = Math.round((targetCalories * 0.25) / 9);
  const targetCarbs = Math.round((targetCalories - (targetProtein * 4 + targetFat * 9)) / 4);

  const handleAnalyzeMeal = async () => {
    if (!mealInput.trim()) return;
    setIsAnalyzing(true);
    setAnalysisResult(null);

    try {
      const res = await fetch('/api/nutrition/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ description: mealInput }),
      });
      const json = await res.json();
      if (json.success && json.data) {
        setAnalysisResult(json.data);
      }
    } catch (err) {
      console.error('Error analyzing meal:', err);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleConfirmAddAnalysis = () => {
    if (!analysisResult) return;
    const newMeal: MealItem = {
      id: `meal-${Date.now()}`,
      name: analysisResult.mealName || mealInput,
      calories: analysisResult.calories,
      protein: analysisResult.protein,
      carbs: analysisResult.carbs,
      fat: analysisResult.fat,
      fitnessScore: analysisResult.fitnessScore,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };
    onAddMeal(newMeal);
    setMealInput('');
    setAnalysisResult(null);
  };

  const handleQuickAdd = (preset: { name: string; calories: number; protein: number; carbs: number; fat: number; score: string }) => {
    const newMeal: MealItem = {
      id: `meal-${Date.now()}`,
      name: preset.name,
      calories: preset.calories,
      protein: preset.protein,
      carbs: preset.carbs,
      fat: preset.fat,
      fitnessScore: preset.score,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };
    onAddMeal(newMeal);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div>
        <span className="text-xs font-semibold text-lime-400 uppercase tracking-wider">
          Fuel & Recovery
        </span>
        <h1 className="font-display text-2xl sm:text-3xl font-extrabold text-zinc-100">
          Nutrition & Macro Tracker
        </h1>
        <p className="mt-1 text-sm text-zinc-400">
          Track calorie intake, macronutrients, and hydration with instant AI meal scanning.
        </p>
      </div>

      {/* Macro Targets 4-Card Overview */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
        {/* Calories */}
        <div className="rounded-2xl border border-zinc-800 bg-zinc-900/80 p-4">
          <span className="text-xs font-medium text-zinc-400">Total Calories</span>
          <div className="mt-1 flex items-baseline gap-1">
            <span className="font-display text-2xl sm:text-3xl font-bold text-zinc-100 tabular-nums">
              {totalCalories}
            </span>
            <span className="text-xs text-zinc-400">/ {targetCalories}</span>
          </div>
          <div className="mt-2 h-1.5 w-full rounded-full bg-zinc-800 overflow-hidden">
            <div
              className="h-full bg-lime-400 transition-all duration-300"
              style={{ width: `${Math.min(100, (totalCalories / targetCalories) * 100)}%` }}
            />
          </div>
        </div>

        {/* Protein */}
        <div className="rounded-2xl border border-zinc-800 bg-zinc-900/80 p-4">
          <span className="text-xs font-medium text-lime-400">Protein (g)</span>
          <div className="mt-1 flex items-baseline gap-1">
            <span className="font-display text-2xl sm:text-3xl font-bold text-lime-400 tabular-nums">
              {totalProtein}g
            </span>
            <span className="text-xs text-zinc-400">/ {targetProtein}g</span>
          </div>
          <div className="mt-2 h-1.5 w-full rounded-full bg-zinc-800 overflow-hidden">
            <div
              className="h-full bg-lime-400 transition-all duration-300"
              style={{ width: `${Math.min(100, (totalProtein / targetProtein) * 100)}%` }}
            />
          </div>
        </div>

        {/* Carbohydrates */}
        <div className="rounded-2xl border border-zinc-800 bg-zinc-900/80 p-4">
          <span className="text-xs font-medium text-amber-400">Carbohydrates (g)</span>
          <div className="mt-1 flex items-baseline gap-1">
            <span className="font-display text-2xl sm:text-3xl font-bold text-amber-400 tabular-nums">
              {totalCarbs}g
            </span>
            <span className="text-xs text-zinc-400">/ {targetCarbs}g</span>
          </div>
          <div className="mt-2 h-1.5 w-full rounded-full bg-zinc-800 overflow-hidden">
            <div
              className="h-full bg-amber-400 transition-all duration-300"
              style={{ width: `${Math.min(100, (totalCarbs / targetCarbs) * 100)}%` }}
            />
          </div>
        </div>

        {/* Fats */}
        <div className="rounded-2xl border border-zinc-800 bg-zinc-900/80 p-4">
          <span className="text-xs font-medium text-cyan-400">Healthy Fats (g)</span>
          <div className="mt-1 flex items-baseline gap-1">
            <span className="font-display text-2xl sm:text-3xl font-bold text-cyan-400 tabular-nums">
              {totalFat}g
            </span>
            <span className="text-xs text-zinc-400">/ {targetFat}g</span>
          </div>
          <div className="mt-2 h-1.5 w-full rounded-full bg-zinc-800 overflow-hidden">
            <div
              className="h-full bg-cyan-400 transition-all duration-300"
              style={{ width: `${Math.min(100, (totalFat / targetFat) * 100)}%` }}
            />
          </div>
        </div>
      </div>

      {/* Hydration Tracker Card */}
      <div className="rounded-2xl border border-zinc-800 bg-zinc-900/80 p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/30">
            <Droplets className="h-6 w-6" />
          </div>
          <div>
            <h3 className="font-display text-base sm:text-lg font-bold text-zinc-100">
              Daily Water Hydration: <span className="tabular-nums font-mono text-cyan-400">{waterMl} ml</span>
            </h3>
            <p className="text-xs text-zinc-400">
              Goal: {profile.dailyWaterTargetMl} ml · Keep muscle tissues pliable and lubricated.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => onAddWater(250)}
            className="flex items-center gap-1.5 rounded-xl border border-zinc-700 bg-zinc-800 px-3.5 py-2 text-xs font-bold text-cyan-300 hover:bg-zinc-700 active:scale-95"
          >
            <Plus className="h-3.5 w-3.5" /> +250 ml (Glass)
          </button>
          <button
            onClick={() => onAddWater(500)}
            className="flex items-center gap-1.5 rounded-xl bg-cyan-500/20 border border-cyan-400/40 px-3.5 py-2 text-xs font-bold text-cyan-300 hover:bg-cyan-500/30 active:scale-95"
          >
            <Plus className="h-3.5 w-3.5" /> +500 ml (Bottle)
          </button>
        </div>
      </div>

      {/* AI Meal Analyzer Input */}
      <div className="rounded-2xl border border-zinc-800 bg-zinc-900/90 p-5 sm:p-6 shadow-xl">
        <div className="flex items-center gap-2 text-xs font-semibold text-lime-400 mb-1">
          <Sparkles className="h-4 w-4" />
          <span>AI Natural Language Meal Scanner</span>
        </div>
        <h2 className="font-display text-lg sm:text-xl font-bold text-zinc-100">
          Log Any Meal in Plain English
        </h2>
        <p className="text-xs text-zinc-400 mb-4">
          Type or paste ingredients (e.g., "1 cup rolled oats, 1 scoop whey, 1 tbsp peanut butter, half apple").
        </p>

        <div className="flex flex-col sm:flex-row gap-2">
          <input
            type="text"
            placeholder="What did you fuel with? e.g. 200g chicken breast, sweet potato, steamed broccoli..."
            value={mealInput}
            onChange={(e) => setMealInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleAnalyzeMeal()}
            className="flex-1 rounded-xl border border-zinc-800 bg-zinc-950 px-4 py-3 text-xs sm:text-sm text-zinc-200 placeholder:text-zinc-600 focus:border-lime-400 focus:outline-none"
          />
          <button
            disabled={isAnalyzing || !mealInput.trim()}
            onClick={handleAnalyzeMeal}
            className="flex items-center justify-center gap-2 rounded-xl bg-lime-400 px-6 py-3 text-xs sm:text-sm font-bold text-zinc-950 shadow-md shadow-lime-400/20 hover:bg-lime-300 active:scale-[0.98] disabled:opacity-50 whitespace-nowrap"
          >
            {isAnalyzing ? (
              <>
                <RotateCw className="h-4 w-4 animate-spin" />
                Analyzing...
              </>
            ) : (
              <>
                <Sparkles className="h-4 w-4" />
                Analyze Meal
              </>
            )}
          </button>
        </div>

        {/* Quick Food Presets */}
        <div className="mt-4 flex flex-wrap items-center gap-2 pt-2 border-t border-zinc-800/80">
          <span className="text-xs text-zinc-400">Quick Add:</span>
          {[
            { name: 'Whey Protein Shake', calories: 140, protein: 25, carbs: 3, fat: 2, score: 'A+' },
            { name: 'Chicken & Rice Bowl', calories: 520, protein: 45, carbs: 60, fat: 10, score: 'A' },
            { name: '3 Scrambled Eggs & Sourdough', calories: 380, protein: 24, carbs: 28, fat: 18, score: 'A' },
            { name: 'Greek Yogurt & Blueberries', calories: 190, protein: 18, carbs: 22, fat: 3, score: 'A+' },
          ].map((item, idx) => (
            <button
              key={idx}
              onClick={() => handleQuickAdd(item)}
              className="rounded-lg border border-zinc-800 bg-zinc-950 px-2.5 py-1 text-xs text-zinc-300 hover:border-zinc-700 hover:text-white"
            >
              + {item.name}
            </button>
          ))}
        </div>

        {/* Analysis Result Confirmation Card */}
        {analysisResult && (
          <div className="mt-5 rounded-xl border border-lime-400/40 bg-zinc-950 p-4 animate-in fade-in slide-in-from-top-2 duration-300">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-zinc-800 pb-3">
              <div>
                <div className="flex items-center gap-2">
                  <h4 className="font-display text-base font-bold text-zinc-100">
                    {analysisResult.mealName}
                  </h4>
                  <span className="rounded bg-lime-400/10 px-2 py-0.5 text-xs font-bold text-lime-400 border border-lime-400/20">
                    Grade {analysisResult.fitnessScore}
                  </span>
                </div>
                <p className="text-xs text-zinc-400 mt-0.5">{analysisResult.verdict}</p>
              </div>

              <button
                onClick={handleConfirmAddAnalysis}
                className="flex items-center justify-center gap-1.5 rounded-lg bg-lime-400 px-4 py-2 text-xs font-bold text-zinc-950 hover:bg-lime-300 active:scale-95"
              >
                <CheckCircle2 className="h-4 w-4" />
                Add to Daily Log
              </button>
            </div>

            {/* Macro Pill breakdown */}
            <div className="mt-3 grid grid-cols-4 gap-2 text-center text-xs font-mono">
              <div className="rounded bg-zinc-900 p-2">
                <span className="text-zinc-400 text-[10px] block">Calories</span>
                <span className="font-bold text-zinc-100 text-sm">{analysisResult.calories}</span>
              </div>
              <div className="rounded bg-zinc-900 p-2">
                <span className="text-lime-400 text-[10px] block">Protein</span>
                <span className="font-bold text-lime-400 text-sm">{analysisResult.protein}g</span>
              </div>
              <div className="rounded bg-zinc-900 p-2">
                <span className="text-amber-400 text-[10px] block">Carbs</span>
                <span className="font-bold text-amber-400 text-sm">{analysisResult.carbs}g</span>
              </div>
              <div className="rounded bg-zinc-900 p-2">
                <span className="text-cyan-400 text-[10px] block">Fat</span>
                <span className="font-bold text-cyan-400 text-sm">{analysisResult.fat}g</span>
              </div>
            </div>

            <p className="mt-2 text-[11px] text-zinc-400 italic">
              Insight: {analysisResult.macroInsight}
            </p>
          </div>
        )}
      </div>

      {/* Logged Meals for Today */}
      <div className="rounded-2xl border border-zinc-800 bg-zinc-900/70 p-5">
        <h3 className="font-display text-lg font-bold text-zinc-100 mb-4">
          Today's Logged Meals ({meals.length})
        </h3>

        {meals.length === 0 ? (
          <p className="text-xs text-zinc-500 py-6 text-center">
            No meals logged yet today. Use the AI Meal Scanner above to track your fuel!
          </p>
        ) : (
          <div className="space-y-2">
            {meals.map((meal) => (
              <div
                key={meal.id}
                className="flex items-center justify-between rounded-xl border border-zinc-800 bg-zinc-950/80 px-4 py-3 transition-colors hover:border-zinc-700"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-semibold text-zinc-200">{meal.name}</span>
                    <span className="text-[11px] text-zinc-400">{meal.timestamp}</span>
                  </div>
                  <div className="mt-1 flex items-center gap-2 text-xs font-mono text-zinc-400 tabular-nums">
                    <span className="text-zinc-200 font-bold">{meal.calories} kcal</span>
                    <span aria-hidden="true">·</span>
                    <span className="text-lime-400">{meal.protein}g P</span>
                    <span aria-hidden="true">·</span>
                    <span className="text-amber-400">{meal.carbs}g C</span>
                    <span aria-hidden="true">·</span>
                    <span className="text-cyan-400">{meal.fat}g F</span>
                  </div>
                </div>

                <button
                  onClick={() => onDeleteMeal(meal.id)}
                  className="rounded-lg p-1.5 text-zinc-400 hover:bg-zinc-800 hover:text-red-400 transition-colors"
                  title="Remove meal"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
