import React, { useState, useMemo } from 'react';
import {
  Search,
  Dumbbell,
  Sparkles,
  ChevronRight,
  Info,
  CheckCircle2,
  AlertTriangle,
  Wind,
  ShieldCheck,
  X,
  RotateCw,
} from 'lucide-react';
import { EXERCISE_DATABASE } from '../data/exerciseDatabase';
import { ExerciseItem } from '../types';

export const ExerciseLibraryView: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedExercise, setSelectedExercise] = useState<ExerciseItem | null>(null);

  // AI Form Check state
  const [aiFormGuide, setAiFormGuide] = useState<{
    targetMuscles: string;
    setupCues: string[];
    executionCues: string[];
    commonMistakes: string[];
    breathingPattern: string;
    safetyTip: string;
  } | null>(null);
  const [isLoadingAiForm, setIsLoadingAiForm] = useState(false);

  const categories = [
    { key: 'all', label: 'All Moves' },
    { key: 'chest', label: 'Chest' },
    { key: 'back', label: 'Back' },
    { key: 'legs', label: 'Legs' },
    { key: 'shoulders', label: 'Shoulders' },
    { key: 'arms', label: 'Arms' },
    { key: 'core', label: 'Core' },
  ];

  const filteredExercises = useMemo(() => {
    return EXERCISE_DATABASE.filter((ex) => {
      const matchesSearch =
        ex.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        ex.targetMuscle.toLowerCase().includes(searchQuery.toLowerCase()) ||
        ex.equipment.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory =
        selectedCategory === 'all' || ex.category === selectedCategory;
      return matchesSearch && matchesCategory;
    });
  }, [searchQuery, selectedCategory]);

  const handleOpenExercise = (ex: ExerciseItem) => {
    setSelectedExercise(ex);
    setAiFormGuide(null);
  };

  const handleFetchAiFormGuide = async () => {
    if (!selectedExercise) return;
    setIsLoadingAiForm(true);

    try {
      const res = await fetch('/api/exercise/form-check', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ exerciseName: selectedExercise.name }),
      });
      const data = await res.json();
      if (data.success && data.data) {
        setAiFormGuide(data.data);
      }
    } catch (err) {
      console.error('Error fetching AI form guide:', err);
    } finally {
      setIsLoadingAiForm(false);
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div>
        <span className="text-xs font-semibold text-lime-400 uppercase tracking-wider">
          Biomechanical Database
        </span>
        <h1 className="font-display text-2xl sm:text-3xl font-extrabold text-zinc-100">
          Exercise & Form Library
        </h1>
        <p className="mt-1 text-sm text-zinc-400">
          Explore proper lifting mechanics, muscle activations, and request instant AI form breakdowns.
        </p>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row gap-3">
        {/* Search Input */}
        <div className="relative flex-1">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-zinc-400" />
          <input
            type="text"
            placeholder="Search exercises by name, muscle, equipment..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full rounded-xl border border-zinc-800 bg-zinc-900/90 pl-10 pr-4 py-2.5 text-xs sm:text-sm text-zinc-200 placeholder:text-zinc-500 focus:border-lime-400 focus:outline-none"
          />
        </div>

        {/* Category Pills */}
        <div className="flex items-center gap-1 overflow-x-auto pb-1 sm:pb-0 scrollbar-none">
          {categories.map((cat) => (
            <button
              key={cat.key}
              onClick={() => setSelectedCategory(cat.key)}
              className={`rounded-lg px-3 py-2 text-xs font-semibold whitespace-nowrap transition-all ${
                selectedCategory === cat.key
                  ? 'bg-lime-400 text-zinc-950 shadow-sm'
                  : 'border border-zinc-800 bg-zinc-900/80 text-zinc-400 hover:text-zinc-200'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* Exercise Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
        {filteredExercises.map((ex) => (
          <div
            key={ex.id}
            onClick={() => handleOpenExercise(ex)}
            className="group cursor-pointer rounded-2xl border border-zinc-800 bg-zinc-900/70 p-4 transition-all hover:border-zinc-700 hover:bg-zinc-900 hover:shadow-lg flex flex-col justify-between"
          >
            <div>
              <div className="flex items-start justify-between gap-2">
                <span className="text-[11px] font-semibold text-lime-400 uppercase tracking-wide">
                  {ex.targetMuscle}
                </span>
                <span className="rounded bg-zinc-800 px-2 py-0.5 text-[10px] font-medium text-zinc-300 capitalize">
                  {ex.difficulty}
                </span>
              </div>

              <h3 className="font-display text-base font-bold text-zinc-100 group-hover:text-lime-400 transition-colors mt-1">
                {ex.name}
              </h3>

              <div className="mt-2 flex items-center gap-2 text-xs text-zinc-400">
                <Dumbbell className="h-3.5 w-3.5 text-zinc-500" />
                <span className="truncate">{ex.equipment}</span>
              </div>

              <p className="mt-2 text-xs text-zinc-400 line-clamp-2">{ex.instructions[0]}</p>
            </div>

            <div className="mt-4 flex items-center justify-between border-t border-zinc-800/80 pt-3">
              <span className="text-[11px] font-mono text-zinc-400 tabular-nums">
                Rec: {ex.recommendedSets} sets × {ex.recommendedReps}
              </span>
              <span className="flex items-center gap-1 text-xs font-semibold text-lime-400 group-hover:translate-x-0.5 transition-transform">
                Guide <ChevronRight className="h-3.5 w-3.5" />
              </span>
            </div>
          </div>
        ))}

        {filteredExercises.length === 0 && (
          <div className="col-span-full rounded-2xl border border-zinc-800 bg-zinc-900/40 p-12 text-center">
            <Dumbbell className="mx-auto h-10 w-10 text-zinc-700 mb-2" />
            <p className="text-sm font-semibold text-zinc-300">No exercises found</p>
            <p className="text-xs text-zinc-500 mt-1">Try clearing your search query or switching categories.</p>
          </div>
        )}
      </div>

      {/* Modal: Exercise Form Detail & AI Coaching Breakdown */}
      {selectedExercise && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-3 sm:p-6 overflow-y-auto">
          <div className="relative w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-2xl border border-zinc-800 bg-zinc-900 p-5 sm:p-6 shadow-2xl">
            {/* Modal Header */}
            <div className="flex items-start justify-between gap-4 border-b border-zinc-800 pb-4">
              <div>
                <span className="text-xs font-semibold text-lime-400 uppercase tracking-wide">
                  {selectedExercise.category} · {selectedExercise.targetMuscle}
                </span>
                <h2 className="font-display text-xl sm:text-2xl font-bold text-zinc-100 mt-1">
                  {selectedExercise.name}
                </h2>
                <div className="mt-1 flex flex-wrap items-center gap-3 text-xs text-zinc-400">
                  <span>Equipment: {selectedExercise.equipment}</span>
                  <span aria-hidden="true">·</span>
                  <span>Level: {selectedExercise.difficulty}</span>
                </div>
              </div>

              <button
                onClick={() => setSelectedExercise(null)}
                className="rounded-lg border border-zinc-700 bg-zinc-800 p-1.5 text-zinc-400 hover:text-white"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {/* Quick Form Cue */}
            <div className="mt-4 rounded-xl border border-lime-400/20 bg-lime-950/20 p-3 text-xs text-lime-300">
              <strong className="font-bold text-lime-200">Key Focus:</strong> {selectedExercise.formCue}
            </div>

            {/* Step-by-Step Instructions */}
            <div className="mt-5">
              <h3 className="text-xs font-semibold text-zinc-300 uppercase tracking-wider mb-2">
                Execution Steps
              </h3>
              <div className="space-y-2">
                {selectedExercise.instructions.map((step, idx) => (
                  <div key={idx} className="flex items-start gap-3 rounded-lg bg-zinc-950/70 p-2.5 text-xs text-zinc-300">
                    <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-zinc-800 font-mono text-[11px] font-bold text-lime-400">
                      {idx + 1}
                    </span>
                    <p className="pt-0.5">{step}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* AI Form Analysis Generator Trigger */}
            <div className="mt-6 border-t border-zinc-800 pt-5">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h4 className="text-xs sm:text-sm font-bold text-zinc-100 flex items-center gap-1.5">
                    <Sparkles className="h-4 w-4 text-lime-400" />
                    AI Biomechanical Breakdown
                  </h4>
                  <p className="text-[11px] text-zinc-400">
                    Detailed joint angles, common errors to avoid, and breathing cadence.
                  </p>
                </div>

                {!aiFormGuide && (
                  <button
                    disabled={isLoadingAiForm}
                    onClick={handleFetchAiFormGuide}
                    className="flex items-center justify-center gap-2 rounded-xl bg-zinc-800 border border-zinc-700 px-4 py-2 text-xs font-bold text-zinc-200 hover:bg-zinc-700 active:scale-[0.98] disabled:opacity-50 whitespace-nowrap"
                  >
                    {isLoadingAiForm ? (
                      <>
                        <RotateCw className="h-3.5 w-3.5 animate-spin" />
                        Analyzing...
                      </>
                    ) : (
                      <>
                        <Sparkles className="h-3.5 w-3.5 text-lime-400" />
                        Analyze Form with AI
                      </>
                    )}
                  </button>
                )}
              </div>

              {/* Render AI Form Details */}
              {aiFormGuide && (
                <div className="mt-4 space-y-3 rounded-xl border border-zinc-800 bg-zinc-950 p-4 animate-in fade-in duration-300">
                  {/* Setup & Execution */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                    <div>
                      <span className="font-semibold text-zinc-300 flex items-center gap-1 mb-1.5">
                        <CheckCircle2 className="h-3.5 w-3.5 text-lime-400" /> Setup Checklist
                      </span>
                      <ul className="space-y-1 text-zinc-400 list-disc list-inside">
                        {aiFormGuide.setupCues.map((c, i) => (
                          <li key={i}>{c}</li>
                        ))}
                      </ul>
                    </div>

                    <div>
                      <span className="font-semibold text-zinc-300 flex items-center gap-1 mb-1.5">
                        <ShieldCheck className="h-3.5 w-3.5 text-cyan-400" /> Execution Cues
                      </span>
                      <ul className="space-y-1 text-zinc-400 list-disc list-inside">
                        {aiFormGuide.executionCues.map((c, i) => (
                          <li key={i}>{c}</li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  {/* Common Mistakes */}
                  <div className="border-t border-zinc-900 pt-3">
                    <span className="font-semibold text-amber-400 flex items-center gap-1 text-xs mb-1.5">
                      <AlertTriangle className="h-3.5 w-3.5" /> Common Biomechanical Errors
                    </span>
                    <ul className="space-y-1 text-xs text-zinc-400 list-disc list-inside">
                      {aiFormGuide.commonMistakes.map((m, i) => (
                        <li key={i}>{m}</li>
                      ))}
                    </ul>
                  </div>

                  {/* Breathing Pattern & Safety */}
                  <div className="border-t border-zinc-900 pt-3 flex flex-col sm:flex-row gap-3 text-xs">
                    <div className="flex-1 rounded-lg bg-zinc-900/80 p-2.5">
                      <span className="font-semibold text-zinc-300 flex items-center gap-1 mb-1">
                        <Wind className="h-3.5 w-3.5 text-cyan-400" /> Breathing Cadence
                      </span>
                      <p className="text-zinc-400">{aiFormGuide.breathingPattern}</p>
                    </div>

                    <div className="flex-1 rounded-lg bg-zinc-900/80 p-2.5">
                      <span className="font-semibold text-zinc-300 flex items-center gap-1 mb-1">
                        <ShieldCheck className="h-3.5 w-3.5 text-lime-400" /> Safety Note
                      </span>
                      <p className="text-zinc-400">{aiFormGuide.safetyTip}</p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
