import React from 'react';
import { LayoutDashboard, Dumbbell, BookOpen, Utensils, MessageSquare, User } from 'lucide-react';

interface MobileBottomNavProps {
  activeTab: 'today' | 'workouts' | 'exercises' | 'nutrition' | 'coach' | 'profile';
  setActiveTab: (tab: 'today' | 'workouts' | 'exercises' | 'nutrition' | 'coach' | 'profile') => void;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({ activeTab, setActiveTab }) => {
  const tabs = [
    { key: 'today', label: 'Today', icon: LayoutDashboard },
    { key: 'workouts', label: 'Workouts', icon: Dumbbell },
    { key: 'exercises', label: 'Library', icon: BookOpen },
    { key: 'nutrition', label: 'Macros', icon: Utensils },
    { key: 'coach', label: 'AI Coach', icon: MessageSquare },
    { key: 'profile', label: 'Profile', icon: User },
  ] as const;

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 block border-t border-zinc-800 bg-zinc-950/95 backdrop-blur-md md:hidden">
      <div className="grid grid-cols-6 items-center h-16 px-1">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.key;
          return (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={`flex flex-col items-center justify-center py-1 transition-colors min-h-[44px] ${
                isActive ? 'text-lime-400' : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <Icon className={`h-5 w-5 ${isActive ? 'stroke-[2.5]' : 'stroke-2'}`} />
              <span className="text-[10px] font-medium tracking-tight mt-1 truncate max-w-full">
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
