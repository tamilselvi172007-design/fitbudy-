import React, { useState } from 'react';
import {
  Sparkles,
  Dumbbell,
  Clock,
  Flame,
  Play,
  RotateCw,
  Plus,
  ChevronDown,
  ChevronUp,
  Info,
  Check,
} from 'lucide-react';
import { WorkoutPlan, FitnessGoal, ExperienceLevel } from '../types';
import { WORKOUT_PRESETS } from '../data/workoutPresets';

interface WorkoutPlannerViewProps {
  onStartWorkout: (workout: WorkoutPlan) => void;
}

export const WorkoutPlannerView: React.FC<WorkoutPlannerViewProps> = ({ onStartWorkout }) => {
  const [activeTab, setActiveTab] = useState<'presets' | 'ai-generator'>('presets');

  // Generator form states
  const [athleteName, setAthleteName] = useState<string>('Alex');
  const [athleteAge, setAthleteAge] = useState<number>(25);
  const [goal, setGoal] = useState<FitnessGoal>('hypertrophy');
  const [level, setLevel] = useState<ExperienceLevel>('intermediate');
  const [duration, setDuration] = useState<number>(30);
  const [selectedMuscles, setSelectedMuscles] = useState<string[]>(['Full Body']);
  const [selectedEquipment, setSelectedEquipment] = useState<string[]>(['Dumbbells']);
  const [limitations, setLimitations] = useState<string>('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedWorkout, setGeneratedWorkout] = useState<WorkoutPlan | null>(null);

  // Expanded details for presets
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const muscleOptions = [
    'Full Body',
    'Chest',
    'Back',
    'Shoulders',
    'Legs & Glutes',
    'Arms',
    'Core & Abs',
  ];

  const equipmentOptions = [
    'Dumbbells',
    'Barbell',
    'Bodyweight',
    'Cables',
    'Pull-Up Bar',
    'Resistance Bands',
    'Kettlebell',
  ];

  const toggleMuscle = (muscle: string) => {
    if (muscle === 'Full Body') {
      setSelectedMuscles(['Full Body']);
      return;
    }
    const withoutFull = selectedMuscles.filter((m) => m !== 'Full Body');
    if (withoutFull.includes(muscle)) {
      const filtered = withoutFull.filter((m) => m !== muscle);
      setSelectedMuscles(filtered.length === 0 ? ['Full Body'] : filtered);
    } else {
      setSelectedMuscles([...withoutFull, muscle]);
    }
  };

  const toggleEquipment = (eq: string) => {
    if (selectedEquipment.includes(eq)) {
      if (selectedEquipment.length > 1) {
        setSelectedEquipment(selectedEquipment.filter((item) => item !== eq));
      }
    } else {
      setSelectedEquipment([...selectedEquipment, eq]);
    }
  };

  const handleGenerateWorkout = async () => {
    setIsGenerating(true);
    setGeneratedWorkout(null);

    try {
      const response = await fetch('/api/workout/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: athleteName,
          age: athleteAge,
          goal,
          level,
          targetMuscles: selectedMuscles,
          equipment: selectedEquipment,
          durationMinutes: duration,
          limitations: limitations.trim() || 'none',
        }),
      });

      const json = await response.json();
      if (json.success && json.data) {
        const plan: WorkoutPlan = {
          id: `custom-${Date.now()}`,
          title: json.data.title || 'Personalized Workout Plan',
          description: json.data.description || 'Custom tailored workout routine.',
          focus: json.data.focus || selectedMuscles.join(', '),
          estimatedCalories: json.data.estimatedCalories || Math.round(duration * 8),
          durationMinutes: duration,
          warmup: json.data.warmup || [],
          exercises: json.data.exercises || [],
          cooldown: json.data.cooldown || [],
          isCustom: true,
        };
        setGeneratedWorkout(plan);
      }
    } catch (err) {
      console.error('Failed to generate workout:', err);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header and segmented selector */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <span className="text-xs font-semibold text-lime-400 uppercase tracking-wider">
            Training Architect
          </span>
          <h1 className="font-display text-2xl sm:text-3xl font-extrabold text-zinc-100">
            Workouts & Routines
          </h1>
          <p className="mt-1 text-sm text-zinc-400">
            Pick from certified athlete presets or prompt FitBuddy to generate a custom routine.
          </p>
        </div>

        {/* Tab segmented controls */}
        <div className="flex items-center gap-1 rounded-xl border border-zinc-800 bg-zinc-900/90 p-1">
          <button
            onClick={() => setActiveTab('presets')}
            className={`px-4 py-2 text-xs font-bold transition-all rounded-lg ${
              activeTab === 'presets'
                ? 'bg-zinc-800 text-lime-400 shadow-sm'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            Curated Presets
          </button>
          <button
            onClick={() => setActiveTab('ai-generator')}
            className={`flex items-center gap-1.5 px-4 py-2 text-xs font-bold transition-all rounded-lg ${
              activeTab === 'ai-generator'
                ? 'bg-lime-400 text-zinc-950 shadow-sm'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <Sparkles className="h-3.5 w-3.5" />
            AI Generator
          </button>
        </div>
      </div>

      {/* View: Curated Presets */}
      {activeTab === 'presets' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {WORKOUT_PRESETS.map((preset) => {
              const isExpanded = expandedId === preset.id;
              return (
                <div
                  key={preset.id}
                  className="rounded-2xl border border-zinc-800 bg-zinc-900/70 p-5 transition-all hover:border-zinc-700 flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <span className="text-xs font-semibold text-lime-400 uppercase tracking-wider">
                          {preset.focus}
                        </span>
                        <h3 className="font-display text-xl font-bold text-zinc-100 mt-0.5">
                          {preset.title}
                        </h3>
                      </div>
                      <span className="rounded bg-zinc-800 px-2 py-1 text-xs font-mono text-zinc-300 tabular-nums">
                        {preset.durationMinutes} min
                      </span>
                    </div>

                    <p className="mt-2 text-xs text-zinc-400 line-clamp-2">
                      {preset.description}
                    </p>

                    <div className="mt-4 flex items-center gap-3 text-xs text-zinc-400">
                      <span>{preset.exercises.length} Exercises</span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono tabular-nums text-zinc-300">
                        ~{preset.estimatedCalories} kcal
                      </span>
                    </div>

                    {/* Collapsible Exercise List */}
                    {isExpanded && (
                      <div className="mt-4 space-y-2 border-t border-zinc-800 pt-3">
                        <p className="text-[11px] font-semibold text-zinc-400 uppercase">
                          Exercise Breakdown
                        </p>
                        {preset.exercises.map((ex, idx) => (
                          <div
                            key={idx}
                            className="flex items-center justify-between rounded-lg bg-zinc-950/60 px-3 py-2 text-xs"
                          >
                            <span className="font-medium text-zinc-200">
                              {idx + 1}. {ex.name}
                            </span>
                            <span className="font-mono text-zinc-400 tabular-nums">
                              {ex.sets} sets × {ex.reps}
                            </span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  <div className="mt-5 flex items-center justify-between gap-2 pt-3 border-t border-zinc-800/80">
                    <button
                      onClick={() => setExpandedId(isExpanded ? null : preset.id)}
                      className="flex items-center gap-1 text-xs font-medium text-zinc-400 hover:text-zinc-200"
                    >
                      {isExpanded ? 'Hide Details' : 'View Exercises'}
                      {isExpanded ? (
                        <ChevronUp className="h-3.5 w-3.5" />
                      ) : (
                        <ChevronDown className="h-3.5 w-3.5" />
                      )}
                    </button>

                    <button
                      onClick={() => onStartWorkout(preset)}
                      className="flex items-center gap-1.5 rounded-xl bg-lime-400 px-4 py-2 text-xs font-bold text-zinc-950 shadow-md shadow-lime-400/10 hover:bg-lime-300 active:scale-[0.98]"
                    >
                      <Play className="h-3.5 w-3.5 fill-current" />
                      Start Workout
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* View: AI Workout Generator */}
      {activeTab === 'ai-generator' && (
        <div className="space-y-6">
          <div className="rounded-2xl border border-zinc-800 bg-zinc-900/80 p-5 sm:p-6">
            <div className="flex items-center gap-2 text-xs font-semibold text-lime-400 mb-1">
              <Sparkles className="h-4 w-4" />
              <span>Smart Exercise Architect</span>
            </div>
            <h2 className="font-display text-xl font-bold text-zinc-100">
              Customize Your Training Parameters
            </h2>
            <p className="text-xs sm:text-sm text-zinc-400 mb-6">
              Our AI builds an anatomically balanced routine based on your equipment, goals, and available minutes.
            </p>

            <div className="space-y-5">
              {/* Athlete Profile: Name & Age */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-zinc-300 mb-1">
                    Athlete Name
                  </label>
                  <input
                    type="text"
                    value={athleteName}
                    onChange={(e) => setAthleteName(e.target.value)}
                    placeholder="e.g. Alex"
                    className="w-full rounded-xl border border-zinc-800 bg-zinc-950 px-3.5 py-2.5 text-xs text-zinc-200 placeholder:text-zinc-600 focus:border-lime-400 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-zinc-300 mb-1">
                    Age (Years)
                  </label>
                  <input
                    type="number"
                    value={athleteAge}
                    onChange={(e) => setAthleteAge(Number(e.target.value))}
                    min={12}
                    max={100}
                    className="w-full rounded-xl border border-zinc-800 bg-zinc-950 px-3.5 py-2.5 text-xs font-mono text-zinc-200 focus:border-lime-400 focus:outline-none"
                  />
                </div>
              </div>

              {/* Primary Goal */}
              <div>
                <label className="block text-xs font-semibold text-zinc-300 mb-2">
                  Primary Fitness Goal
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                  {(['hypertrophy', 'strength', 'fat_loss', 'endurance', 'mobility'] as FitnessGoal[]).map((g) => (
                    <button
                      key={g}
                      onClick={() => setGoal(g)}
                      className={`rounded-xl border p-2.5 text-xs font-semibold capitalize transition-all ${
                        goal === g
                          ? 'border-lime-400 bg-lime-400/10 text-lime-400'
                          : 'border-zinc-800 bg-zinc-950/60 text-zinc-400 hover:border-zinc-700'
                      }`}
                    >
                      {g.replace('_', ' ')}
                    </button>
                  ))}
                </div>
              </div>

              {/* Target Muscles */}
              <div>
                <label className="block text-xs font-semibold text-zinc-300 mb-2">
                  Target Muscle Focus
                </label>
                <div className="flex flex-wrap gap-2">
                  {muscleOptions.map((m) => {
                    const isSelected = selectedMuscles.includes(m);
                    return (
                      <button
                        key={m}
                        onClick={() => toggleMuscle(m)}
                        className={`flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs font-medium transition-all ${
                          isSelected
                            ? 'border-lime-400/60 bg-lime-400/10 text-lime-300'
                            : 'border-zinc-800 bg-zinc-950 text-zinc-400 hover:border-zinc-700'
                        }`}
                      >
                        {isSelected && <Check className="h-3 w-3" />}
                        {m}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Equipment Available */}
              <div>
                <label className="block text-xs font-semibold text-zinc-300 mb-2">
                  Equipment Available
                </label>
                <div className="flex flex-wrap gap-2">
                  {equipmentOptions.map((eq) => {
                    const isSelected = selectedEquipment.includes(eq);
                    return (
                      <button
                        key={eq}
                        onClick={() => toggleEquipment(eq)}
                        className={`flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs font-medium transition-all ${
                          isSelected
                            ? 'border-cyan-400/60 bg-cyan-400/10 text-cyan-300'
                            : 'border-zinc-800 bg-zinc-950 text-zinc-400 hover:border-zinc-700'
                        }`}
                      >
                        {isSelected && <Check className="h-3 w-3" />}
                        {eq}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Duration and Level */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-zinc-300 mb-2">
                    Session Duration
                  </label>
                  <div className="grid grid-cols-4 gap-2">
                    {[15, 30, 45, 60].map((d) => (
                      <button
                        key={d}
                        onClick={() => setDuration(d)}
                        className={`rounded-lg border p-2 text-xs font-mono font-semibold tabular-nums ${
                          duration === d
                            ? 'border-lime-400 bg-lime-400/10 text-lime-400'
                            : 'border-zinc-800 bg-zinc-950 text-zinc-400 hover:border-zinc-700'
                        }`}
                      >
                        {d} min
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-zinc-300 mb-2">
                    Experience Level
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    {(['beginner', 'intermediate', 'advanced'] as ExperienceLevel[]).map((lvl) => (
                      <button
                        key={lvl}
                        onClick={() => setLevel(lvl)}
                        className={`rounded-lg border p-2 text-xs font-semibold capitalize ${
                          level === lvl
                            ? 'border-lime-400 bg-lime-400/10 text-lime-400'
                            : 'border-zinc-800 bg-zinc-950 text-zinc-400 hover:border-zinc-700'
                        }`}
                      >
                        {lvl}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Physical Limitations / Injury Notes */}
              <div>
                <label className="block text-xs font-semibold text-zinc-300 mb-1">
                  Injuries or Adaptations (Optional)
                </label>
                <input
                  type="text"
                  placeholder="e.g. Mild lower back sensitivity, avoid overhead press, knee friendly..."
                  value={limitations}
                  onChange={(e) => setLimitations(e.target.value)}
                  className="w-full rounded-xl border border-zinc-800 bg-zinc-950 px-3.5 py-2.5 text-xs text-zinc-200 placeholder:text-zinc-600 focus:border-lime-400 focus:outline-none"
                />
              </div>

              {/* Submit CTA */}
              <button
                disabled={isGenerating}
                onClick={handleGenerateWorkout}
                className="w-full flex items-center justify-center gap-2 rounded-xl bg-lime-400 py-3 text-sm font-bold text-zinc-950 shadow-lg shadow-lime-400/20 hover:bg-lime-300 active:scale-[0.99] disabled:opacity-50"
              >
                {isGenerating ? (
                  <>
                    <RotateCw className="h-4 w-4 animate-spin" />
                    Synthesizing Routine with AI...
                  </>
                ) : (
                  <>
                    <Sparkles className="h-4 w-4" />
                    Generate Custom Workout
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Generated Result Card */}
          {generatedWorkout && (
            <div className="rounded-2xl border border-lime-400/40 bg-zinc-900/90 p-5 sm:p-6 shadow-2xl animate-in fade-in slide-in-from-bottom-3 duration-300">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-zinc-800 pb-4">
                <div>
                  <div className="flex items-center gap-2 text-xs font-semibold text-lime-400">
                    <Sparkles className="h-3.5 w-3.5" />
                    <span>AI Tailored Protocol</span>
                  </div>
                  <h3 className="font-display text-2xl font-bold text-zinc-100 mt-1">
                    {generatedWorkout.title}
                  </h3>
                  <p className="text-xs text-zinc-300 mt-1">{generatedWorkout.description}</p>
                </div>

                <button
                  onClick={() => onStartWorkout(generatedWorkout)}
                  className="flex items-center justify-center gap-2 rounded-xl bg-lime-400 px-5 py-3 text-xs sm:text-sm font-bold text-zinc-950 shadow-md shadow-lime-400/20 hover:bg-lime-300 active:scale-[0.98] whitespace-nowrap"
                >
                  <Play className="h-4 w-4 fill-current" />
                  Launch Workout
                </button>
              </div>

              {/* Warmup items */}
              {generatedWorkout.warmup?.length > 0 && (
                <div className="mt-4">
                  <h4 className="text-xs font-semibold text-zinc-400 uppercase tracking-wider mb-2">
                    Warmup & Mobility
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {generatedWorkout.warmup.map((w, idx) => (
                      <div
                        key={idx}
                        className="rounded-lg border border-zinc-800 bg-zinc-950 p-2.5 text-xs"
                      >
                        <div className="flex justify-between font-semibold text-zinc-200">
                          <span>{w.name}</span>
                          <span className="font-mono text-zinc-400">{w.durationSec}s</span>
                        </div>
                        <p className="text-[11px] text-zinc-400 mt-1">{w.instructions}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Main Exercises */}
              <div className="mt-5 space-y-3">
                <h4 className="text-xs font-semibold text-zinc-400 uppercase tracking-wider">
                  Main Exercises ({generatedWorkout.exercises.length})
                </h4>
                {generatedWorkout.exercises.map((ex, idx) => (
                  <div
                    key={idx}
                    className="rounded-xl border border-zinc-800 bg-zinc-950/70 p-3.5 transition-colors hover:border-zinc-700"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                      <div>
                        <span className="text-[10px] font-semibold text-lime-400 uppercase">
                          {ex.targetMuscle}
                        </span>
                        <h5 className="font-display text-sm sm:text-base font-bold text-zinc-100">
                          {idx + 1}. {ex.name}
                        </h5>
                      </div>
                      <div className="flex items-center gap-2 text-xs font-mono text-zinc-300 tabular-nums">
                        <span className="rounded bg-zinc-800 px-2 py-0.5">{ex.sets} Sets</span>
                        <span className="rounded bg-zinc-800 px-2 py-0.5">{ex.reps} Reps</span>
                        <span className="rounded bg-zinc-800 px-2 py-0.5">Rest: {ex.restSec}s</span>
                      </div>
                    </div>
                    <div className="mt-2 text-xs text-zinc-400">
                      <p>
                        <strong className="text-zinc-300">Cue:</strong> {ex.formCue}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
