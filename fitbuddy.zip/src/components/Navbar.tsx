import React from 'react';
import { Flame, Play, Dumbbell } from 'lucide-react';

interface NavbarProps {
  activeTab: 'today' | 'workouts' | 'exercises' | 'nutrition' | 'coach' | 'profile';
  setActiveTab: (tab: 'today' | 'workouts' | 'exercises' | 'nutrition' | 'coach' | 'profile') => void;
  streak: number;
  onQuickStart: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ activeTab, setActiveTab, streak, onQuickStart }) => {
  const navItems = [
    { key: 'today', label: 'Today' },
    { key: 'workouts', label: 'Workouts' },
    { key: 'exercises', label: 'Exercises' },
    { key: 'nutrition', label: 'Nutrition' },
    { key: 'coach', label: 'AI Coach' },
    { key: 'profile', label: 'Profile' },
  ] as const;

  return (
    <header className="sticky top-0 z-40 w-full border-b border-zinc-800 bg-zinc-950/90 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        {/* Zone 1: Single text wordmark */}
        <button
          onClick={() => setActiveTab('today')}
          className="group flex items-center gap-2 text-left focus:outline-none"
        >
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-lime-400 text-zinc-950 shadow-sm shadow-lime-400/20 transition-transform group-hover:scale-105">
            <Dumbbell className="h-4 w-4 stroke-[2.5]" />
          </div>
          <span className="font-display text-xl font-bold tracking-tight text-zinc-100 transition-colors group-hover:text-lime-400">
            FitBuddy
          </span>
        </button>

        {/* Zone 2: 4-6 clean text navigation links */}
        <nav className="hidden md:flex items-center gap-1 sm:gap-2">
          {navItems.map((item) => {
            const isActive = activeTab === item.key;
            return (
              <button
                key={item.key}
                onClick={() => setActiveTab(item.key)}
                className={`relative px-3.5 py-1.5 text-sm font-medium transition-colors whitespace-nowrap rounded-md ${
                  isActive
                    ? 'text-lime-400'
                    : 'text-zinc-400 hover:text-zinc-100 hover:bg-zinc-900/60'
                }`}
              >
                {item.label}
                {isActive && (
                  <span className="absolute inset-x-3.5 -bottom-2.5 h-0.5 rounded-full bg-lime-400" />
                )}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: 1-2 primary actions */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold text-amber-400 tabular-nums">
            <Flame className="h-4 w-4 fill-amber-400/20 text-amber-400" />
            <span>{streak} Day Streak</span>
          </div>

          <button
            onClick={onQuickStart}
            className="flex items-center gap-2 rounded-lg bg-lime-400 px-3.5 py-2 text-xs font-bold text-zinc-950 shadow-md shadow-lime-400/10 transition-all hover:bg-lime-300 hover:shadow-lime-400/20 active:scale-[0.98] whitespace-nowrap"
          >
            <Play className="h-3.5 w-3.5 fill-current" />
            <span className="hidden sm:inline">Start Workout</span>
            <span className="sm:hidden">Start</span>
          </button>
        </div>
      </div>
    </header>
  );
};
