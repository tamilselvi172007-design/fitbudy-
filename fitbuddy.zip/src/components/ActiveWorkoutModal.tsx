import React, { useState, useEffect } from 'react';
import { X, Play, Pause, CheckCircle2, ChevronRight, ChevronLeft, RotateCcw, Volume2, Award, Zap } from 'lucide-react';
import { WorkoutPlan, WorkoutLogEntry } from '../types';
import { sounds } from '../utils/audio';

interface ActiveWorkoutModalProps {
  workout: WorkoutPlan;
  unit: 'metric' | 'imperial';
  onClose: () => void;
  onFinishWorkout: (log: WorkoutLogEntry) => void;
}

export const ActiveWorkoutModal: React.FC<ActiveWorkoutModalProps> = ({
  workout,
  unit,
  onClose,
  onFinishWorkout,
}) => {
  // Workout timer
  const [elapsedSeconds, setElapsedSeconds] = useState(0);
  const [isPaused, setIsPaused] = useState(false);

  // Exercise navigation
  const [currentExerciseIndex, setCurrentExerciseIndex] = useState(0);

  // Set tracking per exercise: { [exerciseIndex]: { weight: number, reps: number, completed: boolean }[] }
  const [exerciseSets, setExerciseSets] = useState<{
    [exIndex: number]: { weight: number; reps: number; completed: boolean }[];
  }>(() => {
    const initial: { [key: number]: { weight: number; reps: number; completed: boolean }[] } = {};
    workout.exercises.forEach((ex, idx) => {
      const defaultReps = parseInt(ex.reps.split('-')[0]) || 10;
      initial[idx] = Array.from({ length: ex.sets }, () => ({
        weight: unit === 'metric' ? 40 : 90,
        reps: defaultReps,
        completed: false,
      }));
    });
    return initial;
  });

  // Rest Timer
  const [isResting, setIsResting] = useState(false);
  const [restRemaining, setRestRemaining] = useState(60);
  const [restTotal, setRestTotal] = useState(60);

  // Finished Celebration state
  const [isFinished, setIsFinished] = useState(false);

  // Elapsed workout clock
  useEffect(() => {
    if (isPaused || isFinished) return;
    const interval = setInterval(() => {
      setElapsedSeconds((prev) => prev + 1);
    }, 1000);
    return () => clearInterval(interval);
  }, [isPaused, isFinished]);

  // Rest timer countdown
  useEffect(() => {
    if (!isResting) return;
    const timer = setInterval(() => {
      setRestRemaining((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          setIsResting(false);
          sounds.playTimerDone();
          return 0;
        }
        if (prev <= 4) {
          sounds.playTick();
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [isResting]);

  const currentExercise = workout.exercises[currentExerciseIndex];
  const currentSets = exerciseSets[currentExerciseIndex] || [];

  const handleToggleSet = (setIdx: number) => {
    const updated = [...currentSets];
    const willBeCompleted = !updated[setIdx].completed;
    updated[setIdx] = { ...updated[setIdx], completed: willBeCompleted };

    setExerciseSets((prev) => ({
      ...prev,
      [currentExerciseIndex]: updated,
    }));

    if (willBeCompleted) {
      sounds.playSetComplete();
      // Start rest timer
      const targetRest = currentExercise.restSec || 60;
      setRestTotal(targetRest);
      setRestRemaining(targetRest);
      setIsResting(true);
    }
  };

  const handleUpdateSetValue = (setIdx: number, field: 'weight' | 'reps', value: number) => {
    const updated = [...currentSets];
    updated[setIdx] = { ...updated[setIdx], [field]: Math.max(0, value) };
    setExerciseSets((prev) => ({
      ...prev,
      [currentExerciseIndex]: updated,
    }));
  };

  const totalSetsCompleted = Object.values(exerciseSets).reduce(
    (total, sets) => total + sets.filter((s) => s.completed).length,
    0
  );

  const totalSetsAvailable = workout.exercises.reduce((total, ex) => total + ex.sets, 0);

  const formatTime = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const s = secs % 60;
    return `${mins.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const handleFinish = () => {
    sounds.playVictory();
    setIsFinished(true);

    const log: WorkoutLogEntry = {
      id: `log-${Date.now()}`,
      workoutTitle: workout.title,
      date: new Date().toISOString().split('T')[0],
      durationMinutes: Math.max(1, Math.round(elapsedSeconds / 60)),
      caloriesBurned: Math.round((elapsedSeconds / 60) * 8.5),
      totalSetsCompleted,
      completedExercises: workout.exercises.map((ex, idx) => ({
        exerciseName: ex.name,
        sets: exerciseSets[idx] || [],
      })),
    };

    onFinishWorkout(log);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-2 sm:p-4 overflow-y-auto">
      <div className="relative w-full max-w-3xl overflow-hidden rounded-2xl border border-zinc-800 bg-zinc-900 shadow-2xl">
        {/* Top bar */}
        <div className="flex items-center justify-between border-b border-zinc-800 bg-zinc-950 px-4 py-3 sm:px-6">
          <div className="flex items-center gap-3">
            <span className="flex h-2.5 w-2.5 rounded-full bg-lime-400 animate-pulse" />
            <div>
              <h2 className="font-display text-sm sm:text-base font-bold text-zinc-100 truncate max-w-xs sm:max-w-md">
                {workout.title}
              </h2>
              <div className="flex items-center gap-2 text-xs text-zinc-400">
                <span>{workout.focus}</span>
                <span aria-hidden="true">·</span>
                <span className="tabular-nums font-mono text-lime-400">{formatTime(elapsedSeconds)}</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsPaused(!isPaused)}
              className="flex h-8 w-8 items-center justify-center rounded-lg border border-zinc-700 bg-zinc-800 text-zinc-300 hover:text-white"
              title={isPaused ? 'Resume Workout' : 'Pause Workout'}
            >
              {isPaused ? <Play className="h-4 w-4" /> : <Pause className="h-4 w-4" />}
            </button>
            <button
              onClick={onClose}
              className="flex h-8 w-8 items-center justify-center rounded-lg border border-zinc-700 bg-zinc-800 text-zinc-400 hover:text-white"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Finished State View */}
        {isFinished ? (
          <div className="p-6 sm:p-10 text-center">
            <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-lime-400/10 text-lime-400 ring-1 ring-lime-400/30">
              <Award className="h-8 w-8" />
            </div>
            <h3 className="font-display text-2xl font-bold text-zinc-100">Workout Crushed!</h3>
            <p className="mt-1 text-sm text-zinc-400">
              Incredible effort. Your session has been recorded into your training log.
            </p>

            <div className="mt-6 grid grid-cols-3 gap-3 border-y border-zinc-800 py-4 text-center">
              <div>
                <p className="text-xs text-zinc-400">Duration</p>
                <p className="font-mono text-lg font-bold text-zinc-100 tabular-nums">
                  {Math.round(elapsedSeconds / 60)} min
                </p>
              </div>
              <div>
                <p className="text-xs text-zinc-400">Sets Done</p>
                <p className="font-mono text-lg font-bold text-lime-400 tabular-nums">
                  {totalSetsCompleted} / {totalSetsAvailable}
                </p>
              </div>
              <div>
                <p className="text-xs text-zinc-400">Est. Calories</p>
                <p className="font-mono text-lg font-bold text-amber-400 tabular-nums">
                  {Math.round((elapsedSeconds / 60) * 8.5)} kcal
                </p>
              </div>
            </div>

            <button
              onClick={onClose}
              className="mt-6 w-full rounded-xl bg-lime-400 py-3 text-sm font-bold text-zinc-950 transition hover:bg-lime-300 active:scale-[0.98]"
            >
              Return to Dashboard
            </button>
          </div>
        ) : (
          <div className="p-4 sm:p-6">
            {/* Progress bar */}
            <div className="mb-4">
              <div className="flex items-center justify-between text-xs text-zinc-400 mb-1">
                <span>
                  Exercise {currentExerciseIndex + 1} of {workout.exercises.length}
                </span>
                <span className="tabular-nums">
                  {totalSetsCompleted} / {totalSetsAvailable} Sets Completed
                </span>
              </div>
              <div className="h-1.5 w-full rounded-full bg-zinc-800 overflow-hidden">
                <div
                  className="h-full bg-lime-400 transition-all duration-300"
                  style={{ width: `${(totalSetsCompleted / Math.max(1, totalSetsAvailable)) * 100}%` }}
                />
              </div>
            </div>

            {/* Current Exercise Card */}
            <div className="rounded-xl border border-zinc-800 bg-zinc-950/60 p-4 sm:p-5">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-zinc-800/80 pb-3">
                <div>
                  <span className="text-xs font-semibold text-lime-400 uppercase tracking-wider">
                    {currentExercise.targetMuscle}
                  </span>
                  <h3 className="font-display text-xl font-bold text-zinc-100">
                    {currentExercise.name}
                  </h3>
                </div>
                <div className="flex items-center gap-2 text-xs text-zinc-400">
                  <span className="rounded bg-zinc-800 px-2 py-1 font-mono tabular-nums">
                    Target: {currentExercise.reps} reps
                  </span>
                  <span className="rounded bg-zinc-800 px-2 py-1 font-mono tabular-nums">
                    Rest: {currentExercise.restSec}s
                  </span>
                </div>
              </div>

              {/* Coaching Form Cue */}
              <div className="mt-3 rounded-lg border border-lime-500/20 bg-lime-950/20 px-3 py-2 text-xs text-lime-300 flex items-start gap-2">
                <Zap className="h-4 w-4 shrink-0 text-lime-400 mt-0.5" />
                <p>
                  <strong className="font-semibold text-lime-200">Coach Cue:</strong> {currentExercise.formCue}
                </p>
              </div>

              {/* Sets Table */}
              <div className="mt-5 space-y-2">
                <div className="grid grid-cols-12 gap-2 text-[11px] font-semibold text-zinc-400 uppercase px-2">
                  <div className="col-span-2">Set</div>
                  <div className="col-span-4">Weight ({unit === 'metric' ? 'kg' : 'lbs'})</div>
                  <div className="col-span-3">Reps</div>
                  <div className="col-span-3 text-right">Done</div>
                </div>

                {currentSets.map((set, setIdx) => (
                  <div
                    key={setIdx}
                    className={`grid grid-cols-12 items-center gap-2 rounded-lg border px-3 py-2.5 transition-colors ${
                      set.completed
                        ? 'border-lime-500/40 bg-lime-950/20 text-zinc-200'
                        : 'border-zinc-800 bg-zinc-900/80 text-zinc-300'
                    }`}
                  >
                    <div className="col-span-2 font-mono text-sm font-bold tabular-nums">
                      #{setIdx + 1}
                    </div>

                    <div className="col-span-4">
                      <input
                        type="number"
                        value={set.weight}
                        onChange={(e) => handleUpdateSetValue(setIdx, 'weight', Number(e.target.value))}
                        className="w-full rounded border border-zinc-700 bg-zinc-950 px-2 py-1 font-mono text-sm font-semibold tabular-nums text-zinc-100 focus:border-lime-400 focus:outline-none"
                      />
                    </div>

                    <div className="col-span-3">
                      <input
                        type="number"
                        value={set.reps}
                        onChange={(e) => handleUpdateSetValue(setIdx, 'reps', Number(e.target.value))}
                        className="w-full rounded border border-zinc-700 bg-zinc-950 px-2 py-1 font-mono text-sm font-semibold tabular-nums text-zinc-100 focus:border-lime-400 focus:outline-none"
                      />
                    </div>

                    <div className="col-span-3 flex justify-end">
                      <button
                        onClick={() => handleToggleSet(setIdx)}
                        className={`flex h-8 w-8 items-center justify-center rounded-lg transition-transform active:scale-90 ${
                          set.completed
                            ? 'bg-lime-400 text-zinc-950'
                            : 'border border-zinc-700 bg-zinc-800 text-zinc-400 hover:text-zinc-200'
                        }`}
                      >
                        <CheckCircle2 className="h-5 w-5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Rest Timer Banner */}
            {isResting && (
              <div className="mt-4 flex items-center justify-between rounded-xl border border-lime-400/30 bg-lime-950/40 p-4">
                <div className="flex items-center gap-3">
                  <div className="relative flex h-12 w-12 items-center justify-center">
                    <svg className="h-12 w-12 -rotate-90">
                      <circle
                        cx="24"
                        cy="24"
                        r="20"
                        stroke="currentColor"
                        strokeWidth="3"
                        className="text-zinc-800"
                        fill="transparent"
                      />
                      <circle
                        cx="24"
                        cy="24"
                        r="20"
                        stroke="currentColor"
                        strokeWidth="3"
                        className="text-lime-400 transition-all duration-300"
                        fill="transparent"
                        strokeDasharray={125.6}
                        strokeDashoffset={125.6 * (1 - restRemaining / restTotal)}
                      />
                    </svg>
                    <span className="absolute font-mono text-sm font-bold text-lime-300 tabular-nums">
                      {restRemaining}s
                    </span>
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-zinc-100">Rest Interval</h4>
                    <p className="text-xs text-zinc-400">Catch your breath & hydrate</p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setRestRemaining((prev) => prev + 15)}
                    className="rounded bg-zinc-800 px-2 py-1 text-xs font-semibold text-zinc-300 hover:bg-zinc-700"
                  >
                    +15s
                  </button>
                  <button
                    onClick={() => setIsResting(false)}
                    className="rounded bg-zinc-800 px-2 py-1 text-xs font-semibold text-zinc-300 hover:bg-zinc-700"
                  >
                    Skip
                  </button>
                </div>
              </div>
            )}

            {/* Exercise Navigation Footer */}
            <div className="mt-6 flex items-center justify-between gap-3 border-t border-zinc-800 pt-4">
              <button
                disabled={currentExerciseIndex === 0}
                onClick={() => {
                  setCurrentExerciseIndex((prev) => Math.max(0, prev - 1));
                  setIsResting(false);
                }}
                className="flex items-center gap-1.5 rounded-lg border border-zinc-700 px-3 py-2 text-xs font-semibold text-zinc-300 hover:bg-zinc-800 disabled:opacity-40"
              >
                <ChevronLeft className="h-4 w-4" />
                Previous
              </button>

              {currentExerciseIndex < workout.exercises.length - 1 ? (
                <button
                  onClick={() => {
                    setCurrentExerciseIndex((prev) => prev + 1);
                    setIsResting(false);
                  }}
                  className="flex items-center gap-1.5 rounded-lg bg-zinc-100 px-4 py-2 text-xs font-bold text-zinc-950 hover:bg-white active:scale-[0.98]"
                >
                  Next Exercise
                  <ChevronRight className="h-4 w-4" />
                </button>
              ) : (
                <button
                  onClick={handleFinish}
                  className="flex items-center gap-2 rounded-lg bg-lime-400 px-5 py-2 text-xs font-bold text-zinc-950 shadow-md shadow-lime-400/20 hover:bg-lime-300 active:scale-[0.98]"
                >
                  <Award className="h-4 w-4" />
                  Finish Workout
                </button>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
