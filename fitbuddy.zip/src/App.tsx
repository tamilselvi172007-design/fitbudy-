/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { MobileBottomNav } from './components/MobileBottomNav';
import { DashboardView } from './components/DashboardView';
import { WorkoutPlannerView } from './components/WorkoutPlannerView';
import { ExerciseLibraryView } from './components/ExerciseLibraryView';
import { NutritionView } from './components/NutritionView';
import { BuddyChatView } from './components/BuddyChatView';
import { ProfileView } from './components/ProfileView';
import { ActiveWorkoutModal } from './components/ActiveWorkoutModal';
import {
  UserProfile,
  WorkoutPlan,
  WorkoutLogEntry,
  MealItem,
  AchievementBadge,
  ChatMessage,
} from './types';
import {
  getStoredProfile,
  saveStoredProfile,
  getStoredWorkoutLogs,
  saveWorkoutLog,
  getStoredWater,
  saveStoredWater,
  getStoredMeals,
  saveStoredMeals,
  getStoredBadges,
  unlockBadge,
  getStoredChat,
  saveStoredChat,
} from './utils/storage';
import { WORKOUT_PRESETS } from './data/workoutPresets';

export default function App() {
  const [activeTab, setActiveTab] = useState<
    'today' | 'workouts' | 'exercises' | 'nutrition' | 'coach' | 'profile'
  >('today');

  // Application Data States
  const [profile, setProfile] = useState<UserProfile>(getStoredProfile);
  const [workoutLogs, setWorkoutLogs] = useState<WorkoutLogEntry[]>(getStoredWorkoutLogs);
  const [waterMl, setWaterMl] = useState<number>(getStoredWater);
  const [meals, setMeals] = useState<MealItem[]>(getStoredMeals);
  const [badges, setBadges] = useState<AchievementBadge[]>(getStoredBadges);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>(getStoredChat);
  const [isCoachThinking, setIsCoachThinking] = useState(false);

  // Active workout modal state
  const [activeWorkout, setActiveWorkout] = useState<WorkoutPlan | null>(null);

  // Synchronize state changes to localStorage
  const handleUpdateProfile = (updated: UserProfile) => {
    setProfile(updated);
    saveStoredProfile(updated);
  };

  const handleAddWater = (amount: number) => {
    const updated = waterMl + amount;
    setWaterMl(updated);
    saveStoredWater(updated);
    if (updated >= profile.dailyWaterTargetMl) {
      const updatedBadges = unlockBadge('hydration-hero');
      setBadges(updatedBadges);
    }
  };

  const handleAddMeal = (meal: MealItem) => {
    const updated = [meal, ...meals];
    setMeals(updated);
    saveStoredMeals(updated);
    if (updated.length >= 3) {
      const updatedBadges = unlockBadge('macro-master');
      setBadges(updatedBadges);
    }
  };

  const handleDeleteMeal = (id: string) => {
    const updated = meals.filter((m) => m.id !== id);
    setMeals(updated);
    saveStoredMeals(updated);
  };

  const handleFinishWorkout = (log: WorkoutLogEntry) => {
    const updatedLogs = saveWorkoutLog(log);
    setWorkoutLogs(updatedLogs);

    // Refresh updated profile (streak incremented)
    const freshProfile = getStoredProfile();
    setProfile(freshProfile);

    // Check unlocks
    let freshBadges = getStoredBadges();
    freshBadges = unlockBadge('first-rep');
    if (freshProfile.currentStreak >= 3) {
      freshBadges = unlockBadge('streak-3');
    }
    const totalSets = updatedLogs.reduce((acc, l) => acc + l.totalSetsCompleted, 0);
    if (totalSets >= 100) {
      freshBadges = unlockBadge('century-sets');
    }
    setBadges(freshBadges);
  };

  const handleSendCoachMessage = async (userText: string) => {
    const userMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      role: 'user',
      content: userText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    const updated = [...chatMessages, userMsg];
    setChatMessages(updated);
    saveStoredChat(updated);
    setIsCoachThinking(true);

    try {
      const res = await fetch('/api/buddy/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: updated.map((m) => ({ role: m.role, content: m.content })),
          userContext: {
            goal: profile.goal,
            level: profile.level,
            streak: profile.currentStreak,
            recentWorkout: workoutLogs[0]?.workoutTitle || 'None yet',
          },
        }),
      });

      const data = await res.json();
      const replyText =
        data.reply ||
        "Keep up the high effort and dedication! Form, nutrition, and consistency will carry you to your goals.";

      const assistantMsg: ChatMessage = {
        id: `msg-resp-${Date.now()}`,
        role: 'assistant',
        content: replyText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      const finalMessages = [...updated, assistantMsg];
      setChatMessages(finalMessages);
      saveStoredChat(finalMessages);
    } catch (err) {
      console.error('Error communicating with coach:', err);
      const fallbackMsg: ChatMessage = {
        id: `msg-resp-${Date.now()}`,
        role: 'assistant',
        content:
          "Consistency is key! Remember to maintain a slight calorie surplus if building muscle or a mild deficit for fat loss, hydrate regularly, and get 7-8 hours of quality sleep.",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      const finalMessages = [...updated, fallbackMsg];
      setChatMessages(finalMessages);
      saveStoredChat(finalMessages);
    } finally {
      setIsCoachThinking(false);
    }
  };

  const handleClearChat = () => {
    const initial: ChatMessage[] = [
      {
        id: `msg-${Date.now()}`,
        role: 'assistant',
        content:
          "Fresh slate! What fitness, nutrition, or workout questions can I help you tackle today?",
        timestamp: 'Just now',
      },
    ];
    setChatMessages(initial);
    saveStoredChat(initial);
  };

  // Recommended workout for featured card
  const recommendedWorkout = WORKOUT_PRESETS[0];

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 flex flex-col selection:bg-lime-400 selection:text-zinc-950">
      {/* Top Bar adhering strictly to Top Bar Contract */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        streak={profile.currentStreak}
        onQuickStart={() => setActiveWorkout(recommendedWorkout)}
      />

      {/* Main Content Area */}
      <main className="flex-1 mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8 pt-6 pb-20 md:pb-12">
        {activeTab === 'today' && (
          <DashboardView
            profile={profile}
            waterMl={waterMl}
            onAddWater={handleAddWater}
            todayMeals={meals}
            recentLogs={workoutLogs}
            recommendedWorkout={recommendedWorkout}
            onStartWorkout={(w) => setActiveWorkout(w)}
            onNavigate={(tab) => setActiveTab(tab)}
          />
        )}

        {activeTab === 'workouts' && (
          <WorkoutPlannerView onStartWorkout={(w) => setActiveWorkout(w)} />
        )}

        {activeTab === 'exercises' && <ExerciseLibraryView />}

        {activeTab === 'nutrition' && (
          <NutritionView
            profile={profile}
            meals={meals}
            onAddMeal={handleAddMeal}
            onDeleteMeal={handleDeleteMeal}
            waterMl={waterMl}
            onAddWater={handleAddWater}
          />
        )}

        {activeTab === 'coach' && (
          <BuddyChatView
            profile={profile}
            messages={chatMessages}
            onSendMessage={handleSendCoachMessage}
            onClearChat={handleClearChat}
            isThinking={isCoachThinking}
          />
        )}

        {activeTab === 'profile' && (
          <ProfileView
            profile={profile}
            onUpdateProfile={handleUpdateProfile}
            badges={badges}
            workoutLogs={workoutLogs}
          />
        )}
      </main>

      {/* Active Live Workout Tracker Modal */}
      {activeWorkout && (
        <ActiveWorkoutModal
          workout={activeWorkout}
          unit={profile.unit}
          onClose={() => setActiveWorkout(null)}
          onFinishWorkout={handleFinishWorkout}
        />
      )}

      {/* Mobile Bottom Navigation */}
      <MobileBottomNav activeTab={activeTab} setActiveTab={setActiveTab} />
    </div>
  );
}
