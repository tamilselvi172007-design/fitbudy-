import express, { Request, Response } from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI, Type } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json());

// Initialize Gemini client
const apiKey = process.env.GEMINI_API_KEY;
const ai = apiKey
  ? new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    })
  : null;

// Endpoint: Generate Personalized Workout Plan
app.post('/api/workout/generate', async (req: Request, res: Response) => {
  const {
    name = 'Athlete',
    age = 25,
    goal = 'strength',
    level = 'intermediate',
    targetMuscles = ['full_body'],
    equipment = ['dumbbells'],
    durationMinutes = 30,
    limitations = 'none',
  } = req.body;

  if (ai) {
    try {
      const prompt = `Create a high-energy, scientifically grounded workout routine:
- Athlete Name: ${name}
- Age: ${age}
- Fitness Goal: ${goal}
- Experience Level: ${level}
- Target Muscle Groups: ${targetMuscles.join(', ')}
- Available Equipment: ${equipment.join(', ')}
- Total Duration: ${durationMinutes} minutes
- Physical Limitations or Notes: ${limitations}

Return a structured workout plan designed for maximum athletic performance and enjoyment.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
        config: {
          systemInstruction:
            'You are a premier strength and conditioning coach for FitBuddy. Generate realistic, safe, and effective training routines with clear sets, reps, and precise coaching cues.',
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              description: { type: Type.STRING },
              focus: { type: Type.STRING },
              estimatedCalories: { type: Type.NUMBER },
              warmup: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    name: { type: Type.STRING },
                    durationSec: { type: Type.NUMBER },
                    instructions: { type: Type.STRING },
                  },
                  required: ['name', 'durationSec', 'instructions'],
                },
              },
              exercises: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    id: { type: Type.STRING },
                    name: { type: Type.STRING },
                    targetMuscle: { type: Type.STRING },
                    sets: { type: Type.NUMBER },
                    reps: { type: Type.STRING },
                    restSec: { type: Type.NUMBER },
                    tips: { type: Type.STRING },
                    formCue: { type: Type.STRING },
                  },
                  required: ['id', 'name', 'targetMuscle', 'sets', 'reps', 'restSec', 'tips', 'formCue'],
                },
              },
              cooldown: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    name: { type: Type.STRING },
                    durationSec: { type: Type.NUMBER },
                    instructions: { type: Type.STRING },
                  },
                  required: ['name', 'durationSec', 'instructions'],
                },
              },
            },
            required: ['title', 'description', 'focus', 'estimatedCalories', 'warmup', 'exercises', 'cooldown'],
          },
        },
      });

      const parsed = JSON.parse(response.text || '{}');
      return res.json({ success: true, data: parsed });
    } catch (error) {
      console.error('Error calling Gemini for workout generation:', error);
      // Fallback below
    }
  }

  // Graceful fallback plan
  const fallbackPlan = {
    title: `${goal.charAt(0).toUpperCase() + goal.slice(1)} Performance Protocol`,
    description: `Targeted ${durationMinutes}-minute high-efficiency workout focusing on ${targetMuscles.join(', ')} with ${equipment.join(', ')}.`,
    focus: targetMuscles.join(' & '),
    estimatedCalories: Math.round(durationMinutes * 7.5),
    warmup: [
      { name: 'Arm Circles & Hip Openers', durationSec: 90, instructions: 'Smooth circular rotations to prime joint synovial fluid.' },
      { name: 'Cat-Cow to Bird-Dog', durationSec: 90, instructions: 'Spinal articulation and rotary core activation.' },
    ],
    exercises: [
      {
        id: 'ex-1',
        name: equipment.includes('dumbbells') ? 'Goblet Squat' : 'Bodyweight Air Squat',
        targetMuscle: 'Quadriceps & Glutes',
        sets: 4,
        reps: '10-12',
        restSec: 60,
        tips: 'Keep chest upright, push knees slightly outward over pinky toes.',
        formCue: 'Drive the floor away through mid-foot and heels.',
      },
      {
        id: 'ex-2',
        name: equipment.includes('dumbbells') ? 'Dumbbell Floor Press / Push-up' : 'Tempo Push-up',
        targetMuscle: 'Chest & Triceps',
        sets: 3,
        reps: '10-12',
        restSec: 60,
        tips: 'Control the descent for 2 seconds, drive up explosively.',
        formCue: 'Maintain rigid plank posture, elbows at 45 degrees.',
      },
      {
        id: 'ex-3',
        name: equipment.includes('dumbbells') ? 'Romanian Deadlift' : 'Single-Leg Glute Bridge',
        targetMuscle: 'Hamstrings & Posterior Chain',
        sets: 3,
        reps: '12',
        restSec: 60,
        tips: 'Hinge back at the hips, keeping a neutral flat spine.',
        formCue: 'Feel deep tension in hamstrings before squeezing glutes at top.',
      },
      {
        id: 'ex-4',
        name: 'Plank with Shoulder Taps',
        targetMuscle: 'Core & Stabilizers',
        sets: 3,
        reps: '20 taps',
        restSec: 45,
        tips: 'Resist hip sway and keep pelvic floor engaged.',
        formCue: 'Pretend a glass of water is balancing on your lower back.',
      },
    ],
    cooldown: [
      { name: 'Hamstring & Quad Stretch', durationSec: 60, instructions: 'Deep passive stretch, breathing slowly through nasal passages.' },
      { name: "Child's Pose", durationSec: 60, instructions: 'Relax spine and shoulder girdle with diaphragmatic breaths.' },
    ],
  };

  return res.json({ success: true, data: fallbackPlan });
});

// Endpoint: FitBuddy Interactive Coach Chat
app.post('/api/buddy/chat', async (req: Request, res: Response) => {
  const { messages = [], userContext = {} } = req.body;

  if (ai) {
    try {
      const userPrompt = messages
        .map((m: { role: string; content: string }) => `${m.role === 'user' ? 'Athlete' : 'FitBuddy'}: ${m.content}`)
        .join('\n');

      const systemPrompt = `You are FitBuddy, an elite personal trainer, nutrition coach, and motivational training buddy.
Athlete stats/context:
- Goal: ${userContext.goal || 'General Fitness'}
- Experience: ${userContext.level || 'Intermediate'}
- Current Streak: ${userContext.streak || 0} days
- Recent activity: ${userContext.recentWorkout || 'Active training'}

Tone:
- Energetic, encouraging, grounded in exercise science, and clear.
- Provide punchy, actionable advice with specific numbers (reps, rest, grams of protein) when asked.
- Avoid vague generic fluff. Keep responses concise (under 160 words unless a full routine is requested).
- If asked about pain or injury, advise safe modifications and doctor consultation.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: `${systemPrompt}\n\nConversation history:\n${userPrompt}\n\nFitBuddy:`,
      });

      const reply = response.text?.trim() || "Let's crush this workout! Stay consistent, hydrate, and maintain flawless form.";
      return res.json({ success: true, reply });
    } catch (error) {
      console.error('Error in FitBuddy chat:', error);
    }
  }

  // Fallback intelligent responses
  const lastUserMsg = messages[messages.length - 1]?.content?.toLowerCase() || '';
  let reply = "Keep showing up every day! Consistency over intensity builds lifelong results. What workout are we tackling next?";

  if (lastUserMsg.includes('protein') || lastUserMsg.includes('eat') || lastUserMsg.includes('diet') || lastUserMsg.includes('meal')) {
    reply = "Target 1.6 to 2.2 grams of protein per kilogram of body weight to optimize muscle recovery and satiety. Prioritize lean meats, eggs, Greek yogurt, or plant proteins like tofu and legumes across 3-4 meals daily!";
  } else if (lastUserMsg.includes('sore') || lastUserMsg.includes('rest') || lastUserMsg.includes('recovery')) {
    reply = "Delayed Onset Muscle Soreness (DOMS) is natural! Best active recovery: 20-30 min brisk walk, 500ml water with electrolytes, 8 hours of sleep, and gentle dynamic stretching. Don't train the exact same sore muscle group with heavy loads today.";
  } else if (lastUserMsg.includes('form') || lastUserMsg.includes('squat') || lastUserMsg.includes('deadlift')) {
    reply = "Golden rule of compound lifts: Lock your core before initiating, keep your spine neutral, and control the eccentric (lowering) phase for 2 full seconds. Quality of movement always beats ego lifting weight!";
  }

  return res.json({ success: true, reply });
});

// Endpoint: Nutrition & Macro Analyzer
app.post('/api/nutrition/analyze', async (req: Request, res: Response) => {
  const { description = '' } = req.body;

  if (ai && description.trim()) {
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: `Analyze the following meal or ingredients and estimate accurate nutritional macros:
"${description}"

Return realistic calories, protein, carbohydrates, and healthy fats, along with a brief fitness verdict.`,
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              mealName: { type: Type.STRING },
              calories: { type: Type.NUMBER },
              protein: { type: Type.NUMBER },
              carbs: { type: Type.NUMBER },
              fat: { type: Type.NUMBER },
              fitnessScore: { type: Type.STRING, description: 'e.g. A+, A, B, C' },
              verdict: { type: Type.STRING },
              macroInsight: { type: Type.STRING },
            },
            required: ['mealName', 'calories', 'protein', 'carbs', 'fat', 'fitnessScore', 'verdict', 'macroInsight'],
          },
        },
      });

      const parsed = JSON.parse(response.text || '{}');
      return res.json({ success: true, data: parsed });
    } catch (error) {
      console.error('Error in nutrition analysis:', error);
    }
  }

  // Fallback calculation
  const fallback = {
    mealName: description ? description.slice(0, 32) : 'Balanced Fitness Meal',
    calories: 460,
    protein: 34,
    carbs: 45,
    fat: 14,
    fitnessScore: 'A',
    verdict: 'Nutrient-dense meal with an optimal protein-to-carb ratio for workout fueling and recovery.',
    macroInsight: 'Provides sustained amino acid release and replenishes glycogen reserves without sluggishness.',
  };

  return res.json({ success: true, data: fallback });
});

// Endpoint: Form Check Guide
app.post('/api/exercise/form-check', async (req: Request, res: Response) => {
  const { exerciseName = 'Barbell Back Squat' } = req.body;

  if (ai) {
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: `Provide step-by-step form cues, common biomechanical mistakes, and breathing patterns for "${exerciseName}".`,
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              exerciseName: { type: Type.STRING },
              targetMuscles: { type: Type.STRING },
              setupCues: { type: Type.ARRAY, items: { type: Type.STRING } },
              executionCues: { type: Type.ARRAY, items: { type: Type.STRING } },
              commonMistakes: { type: Type.ARRAY, items: { type: Type.STRING } },
              breathingPattern: { type: Type.STRING },
              safetyTip: { type: Type.STRING },
            },
            required: ['exerciseName', 'targetMuscles', 'setupCues', 'executionCues', 'commonMistakes', 'breathingPattern', 'safetyTip'],
          },
        },
      });

      const parsed = JSON.parse(response.text || '{}');
      return res.json({ success: true, data: parsed });
    } catch (error) {
      console.error('Error in exercise form check:', error);
    }
  }

  const fallback = {
    exerciseName,
    targetMuscles: 'Primary movers and stabilizing synergists',
    setupCues: [
      'Position feet shoulder-width apart with toes flared slightly outwards (15-30 degrees).',
      'Brace abdominal wall as if preparing to take a punch.',
      'Squeeze shoulder blades down and back into your back pockets.',
    ],
    executionCues: [
      'Initiate movement by pushing hips backward while breaking at knees simultaneously.',
      'Descend smoothly until hip crease is level with or below top of patella.',
      'Drive powerfully through mid-foot and heel to return to locked upright standing.',
    ],
    commonMistakes: [
      'Knees caving inward (valgus collapse) on ascending drive.',
      'Rounding the lower lumbar spine at the bottom of range of motion.',
      'Rushing the tempo and bouncing off ligaments.',
    ],
    breathingPattern: 'Inhale deeply and brace into belly before descending. Exhale past the sticking point on ascent.',
    safetyTip: 'Maintain continuous core tension throughout every repetition. Stop if sharp joint pain occurs.',
  };

  return res.json({ success: true, data: fallback });
});

// Vite / Static file serving
async function startServer() {
  const isProduction = process.env.NODE_ENV === 'production';

  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`FitBuddy server listening on port ${PORT}`);
  });
}

startServer();
